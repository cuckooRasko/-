package com.ch.DHMSPro.repository.admin;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.ch.DHMSPro.entity.Hospital;

@Mapper
public interface HospitalRepository {
	int add(Hospital hospital);
	int update(Hospital hospital);
	int selectAll(
        @Param("Name") String  Name
        );
	Hospital select(Integer id);
	List<Map> selectAllByPage(@Param("startIndex") int startIndex, @Param("perPageSize") int perPageSize,
        @Param("Name") String  Name
        );
	int  delete(Integer id);
	List<Hospital> selectAllRecords();
	
	
        Hospital selectByName(String Name);

        
	
        List<Hospital> selectAllName();

        
	
}
