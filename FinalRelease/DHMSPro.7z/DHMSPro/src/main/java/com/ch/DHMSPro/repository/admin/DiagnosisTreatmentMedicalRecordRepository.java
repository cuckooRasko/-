package com.ch.DHMSPro.repository.admin;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.ch.DHMSPro.entity.DiagnosisTreatmentMedicalRecord;

@Mapper
public interface DiagnosisTreatmentMedicalRecordRepository {
	int add(DiagnosisTreatmentMedicalRecord diagnosistreatmentmedicalrecord);
	int update(DiagnosisTreatmentMedicalRecord diagnosistreatmentmedicalrecord);
	int selectAll(
        @Param("DiagnosisTreatmentRegisteredId") String  DiagnosisTreatmentRegisteredId
        );
	DiagnosisTreatmentMedicalRecord select(Integer id);
	List<Map> selectAllByPage(@Param("startIndex") int startIndex, @Param("perPageSize") int perPageSize,
        @Param("DiagnosisTreatmentRegisteredId") String  DiagnosisTreatmentRegisteredId
        );
	int  delete(Integer id);
	List<DiagnosisTreatmentMedicalRecord> selectAllRecords();
	
	
	
	
}
