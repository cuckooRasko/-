package com.ch.DHMSPro.service.admin;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.tomcat.util.http.fileupload.servlet.ServletFileUpload;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.util.WebUtils;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.stream.Collectors;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ch.DHMSPro.entity.Member;
import com.ch.DHMSPro.repository.admin.MemberRepository;
import com.ch.DHMSPro.util.MyUtil;
import com.ch.DHMSPro.util.ExcelUtil;
import com.ch.DHMSPro.util.utlitComm;


@Service("MemberServiceImpl")
public class MemberServiceImpl implements MemberService{
	@Autowired
	private MemberRepository memberRepository;
	
	@Override
	public String selectAllByPage(Model model,Integer currentPage, String act,HttpServletRequest  request) {
		Map<String,String>  searchFieldAndContent = getAllRequestParam(request);
		
		//共多少个商品
	  	int totalCount = memberRepository.selectAll(    
        searchFieldAndContent.get("Name")  
        );
	  	//计算共多少页
	  	int pageSize = 5;
		if (currentPage == null) {
	  		currentPage = 1;
	  	}
	  	int totalPage = (int)Math.ceil(totalCount*1.0/pageSize);
	  	List<Map> curPageObject = memberRepository.selectAllByPage((currentPage-1)*pageSize, pageSize,    
        searchFieldAndContent.get("Name")  
        );
		
        //更新常量
        Map<String, Map<String, String>> publicDict = utlitComm.publicDict();
        
        
         Map<String, String> GenderList = publicDict.get("Gender").entrySet().stream().collect(Collectors.toMap(entry -> entry.getValue(), entry -> entry.getKey()));
        
        
        for (int i = 0 ; i<curPageObject.size();i++)    
        {
            
            
        curPageObject.get(i).put("Gender",GenderList.get(curPageObject.get(i).get("Gender")));
        
            
        }
        
		
		model.addAttribute("Member", searchFieldAndContent);
 		model.addAttribute("curPageObject", curPageObject );
	    	model.addAttribute("totalPage", totalPage);
	    	model.addAttribute("currentPage", currentPage);
	    	model.addAttribute("act", act);
		return "admin/Member/index";
	}

	@Override
	public String save_add(Member member, HttpServletRequest  request) throws IllegalStateException, IOException {
			        
        String AvatarPictureNewName = updateFileField(request,"AvatarPictureFile");  
        member.setAvatarPicture(AvatarPictureNewName);

        
		int n = memberRepository.add(member);
		if(n > 0)//成功
			return "/admin/Member/index?currentPage=1&act=select";
			//失败
		return "fail";//"admin/Member/add";
		
	}
	@Override
	public String save_edit(Member member, HttpServletRequest  request) throws IllegalStateException, IOException {
			        
        String AvatarPictureNewName = updateFileField(request,"AvatarPictureFile");  
        member.setAvatarPicture(AvatarPictureNewName);

        
		int n = memberRepository.update(member);
		if(n > 0)//成功
			return "/admin/Member/index?currentPage=1&act=updateSelect";
			//失败
		return  "fail";//"admin/Member/edit";	
	}
	@Override
	public String add(Member member, Model model) {
		
		return "admin/Member/add";
	}
	@Override
	public String edit(Model model,Integer id) {
		
		model.addAttribute("member", memberRepository.select(id));
		return "admin/Member/edit";
	}
	@Override
	public String detail(Model model, Integer id) {
		model.addAttribute("member", memberRepository.select(id));
		return "admin/Member/detail";		
	}

	@Override
	public String delete(Integer id) {
		
		memberRepository.delete(id);
		return "redirect:/admin/Member/index?currentPage=1&act=deleteSelect";
		
	}

	
        private String processFileUpload(MultipartFile myfile,HttpServletRequest  request) throws IllegalStateException, IOException {
    	String fileNewName = "";
    	System.out.println(myfile !=null);
    	
    	if(myfile !=null && !myfile.isEmpty()) {
			//上传文件路径（生产环境）
			String path = request.getServletContext().getRealPath("/images/");
			//获得上传文件原名
			//上传文件路径（开发环境）
			
			String fileName = myfile.getOriginalFilename();
			//对文件重命名
			fileNewName = MyUtil.getNewFileName(fileName);
			File filePath = new File(path + File.separator + fileNewName);
			//如果文件目录不存在，创建目录
			if(!filePath.getParentFile().exists()) {
				filePath.getParentFile().mkdirs();
			}
			//将上传文件保存到一个目标文件中
			myfile.transferTo(filePath);

		}
    	return fileNewName;
    }
    /*
    * 获取客户端请求参数中所有的信息
    * @param request
    * @return
    */
   private Map<String, String> getAllRequestParam(final HttpServletRequest request) {
       Map<String, String> res = new HashMap<String, String>();
       Enumeration<?> temp = request.getParameterNames();
       if (null != temp) {
           while (temp.hasMoreElements()) {
               String en = (String) temp.nextElement();
               String value = request.getParameter(en);
               res.put(en, value);
               //如果字段的值为空，判断若值为空，则删除这个字段>
               //if (null == res.get(en) || "".equals(res.get(en))) {
                   //res.remove(en);
               //}
           }
       }
       return res;
   }
   private String updateFileField(HttpServletRequest  request,String fileFieldName) throws IllegalStateException, IOException {		
		MultipartFile file = null;
		String fileNewName = "";
		boolean isMultipart = ServletFileUpload.isMultipartContent(request);
		if (isMultipart){
		    MultipartHttpServletRequest multipartRequest =
		    WebUtils.getNativeRequest(request,MultipartHttpServletRequest.class);
		    file = multipartRequest.getFile(fileFieldName);
		    if (!(file == null))
		    {
		    	fileNewName = processFileUpload(file,request);		    	
		    }   	
		}
		return fileNewName;
		
   }

              @Override
	public String importexcel(Member member,HttpServletRequest  request) throws IllegalStateException, IOException {
		try {	
	   		
			MultipartFile file = null;
			String fileFieldName = "uploadExcelFile";
			boolean isMultipart = ServletFileUpload.isMultipartContent(request);
			if (isMultipart){
			    MultipartHttpServletRequest multipartRequest =
			    WebUtils.getNativeRequest(request,MultipartHttpServletRequest.class);
			    MultipartFile myfile = multipartRequest.getFile(fileFieldName);
			    String fileName = myfile.getOriginalFilename();
			    
			    List<Map<String,String>> readFileResult = ExcelUtil.readExcelFile(myfile); //excel读取到的数据
			    System.out.println(readFileResult);
			    Member memberTemp = new Member();
			    
			    Map<String, Map<String, String>> publicDict = utlitComm.publicDict();
			    
        Map<String, String> Gender = publicDict.get("Gender");
        
			    Map<String,String> rowData =  new HashMap<String,String>();
			    for (int i=0;i<readFileResult.size();i++){
			    	rowData = readFileResult.get(i);
			    	for(String key : rowData.keySet()){
			    		   String value = rowData.get(key);
					   
                            if (key.equals("CreatedTime")) {
                               memberTemp.setCreatedTime(value);
                            }
        
                           else  if (key.equals("UpdateTime")) {
                               memberTemp.setUpdateTime(value);
                            }
        
                           else  if (key.equals("Name")) {
                               memberTemp.setName(value);
                            }
        
                           else  if (key.equals("PhoneNumber")) {
                               memberTemp.setPhoneNumber(value);
                            }
        
                           else  if (key.equals("Nickname")) {
                               memberTemp.setNickname(value);
                            }
        
                           else  if (key.equals("AvatarPicture")) {
                               memberTemp.setAvatarPicture(value);
                            }
        
                           else  if (key.equals("Password")) {
                               memberTemp.setPassword(value);
                            }
        
                           else  if (key.equals("Email")) {
                               memberTemp.setEmail(value);
                            }
        
                           else  if (key.equals("NameSurname")) {
                               memberTemp.setNameSurname(value);
                            }
        
                           else  if (key.equals("Gender")) {
                               memberTemp.setGender(Gender.get(value));
                            }
         
			    	}
			    	memberRepository.add(memberTemp); //添加入库
			    	memberTemp = new Member();
			    	

			    }
			return "ok";
			}
			else {
				return "数据文件不存在";
			}
		}catch (Exception e) {
			e.printStackTrace();
			return "数据导入失败，请规范导入模板";
		}
		
	}

}
