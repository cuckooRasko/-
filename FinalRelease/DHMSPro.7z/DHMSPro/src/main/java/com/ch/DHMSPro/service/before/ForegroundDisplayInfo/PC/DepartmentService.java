package com.ch.DHMSPro.service.before.ForegroundDisplayInfo.PC;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;

import org.springframework.ui.Model;

import com.ch.DHMSPro.entity.Department;

public interface DepartmentService {
	
        public String edit(Model model,Integer id);
        
        public String save_edit(Department department, HttpServletRequest  request) throws IllegalStateException, IOException ;
            
        public String selectAllByPage(Model model, Integer currentPage, String act,HttpServletRequest  request);
        
        public String detail(Model model, Integer id);
        
}
