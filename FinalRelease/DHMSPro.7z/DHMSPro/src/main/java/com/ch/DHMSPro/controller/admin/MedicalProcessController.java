package com.ch.DHMSPro.controller.admin;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.ch.DHMSPro.entity.MedicalProcess;
import com.ch.DHMSPro.service.admin.MedicalProcessService;

@Controller("MedicalProcessController")
@RequestMapping("/admin/MedicalProcess")
public class MedicalProcessController extends AdminBaseController{
	@Autowired
	private MedicalProcessService medicalprocessService;
	@RequestMapping("/index")
	public String selectAllByPage(Model model, Integer currentPage, String act, HttpServletRequest  request) {
		return medicalprocessService.selectAllByPage(model, currentPage, act,request);
	}
	@RequestMapping("/add")
	public String add(@ModelAttribute("medicalprocess") MedicalProcess medicalprocess, Model model) {

		return medicalprocessService.add(medicalprocess, model);
	}
	@RequestMapping("/save_add")
	@ResponseBody
	public String save_add(@ModelAttribute("medicalprocess") MedicalProcess medicalprocess, HttpServletRequest  request) throws IllegalStateException, IOException {
		return medicalprocessService.save_add(medicalprocess,request);
	}
	@RequestMapping("/edit")
	public String edit(Model model, Integer id) {

		return medicalprocessService.edit(model, id);
	}
	@RequestMapping("/save_edit")
	@ResponseBody
	public String save_edit(@ModelAttribute("medicalprocess") MedicalProcess medicalprocess, HttpServletRequest  request) throws IllegalStateException, IOException {
		return medicalprocessService.save_edit(medicalprocess, request);
	}
	@RequestMapping("/detail")
	public String detail(Model model, Integer id) {
		return medicalprocessService.detail(model, id);
	}
	@RequestMapping("/delete")
	public String delete(Integer id) {
		return medicalprocessService.delete(id);
	}
	/**
	 * 导入excel
	 */
	@RequestMapping("/importexcel")
	@ResponseBody
	public String importexcel(@ModelAttribute("medicalprocess") MedicalProcess medicalprocess, HttpServletRequest  request) throws IllegalStateException,IOException {
		return medicalprocessService.importexcel(medicalprocess,request);
		
	}
}
