package com.ch.DHMSPro.controller.before.MemberCenter.PC;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.ch.DHMSPro.entity.Member;
import com.ch.DHMSPro.service.before.MemberCenter.PC.UserService;
@Controller("MemberCenterPCMemberUserController")
@RequestMapping("/MemberCenterPC")
public class UserController {
	@Autowired
	private UserService userService;
	@RequestMapping("/toLogin")
	public String toLogin(@ModelAttribute("Member") Member member) {
		//@ModelAttribute("member")与th:object="${member}"相对应
		return "before/MemberCenter/login";
	}
	@RequestMapping("/login")
	public String login(@ModelAttribute("member") @Validated Member member,
			BindingResult rs, HttpSession session, Model model) {
		if(rs.hasErrors()){//验证失败
	        return "before/MemberCenter/login";
	    }
		return userService.login(member, session, model);
	}
	@RequestMapping("/logout")
	public String logout(@ModelAttribute("member") Member member, HttpSession session, Model model) {
		return userService.logout(member, session, model);
	}	
}
