package com.ch.DHMSPro.repository.admin;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.ch.DHMSPro.entity.SystemAccount;

@Mapper
public interface AdminRepository {
	List<SystemAccount> login(SystemAccount systemaccount);
}
