package com.ch.DHMSPro.util;
import java.io.File;
import java.io.IOException;

import javax.servlet.http.HttpServletRequest;


import org.springframework.web.multipart.MultipartFile;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Map;
import com.ch.DHMSPro.util.*;
public class utlitComm {
public static Map<String, Map<String, String>> publicDict(){
	
	Map<String,Map<String,String>> publicDataDict = new HashMap<String, Map<String,String>>();
	
            Map<String,String> MenuType = new HashMap<String,String>();

        
            MenuType.put("后台","5");

        
            MenuType.put("前端顶部","2");

        
            MenuType.put("作者","3");

        
            MenuType.put("前端左部","4");

        
            publicDataDict.put("MenuType", MenuType);
        
            Map<String,String> IsUsed = new HashMap<String,String>();

        
            IsUsed.put("是","3");

        
            IsUsed.put("否","2");

        
            publicDataDict.put("IsUsed", IsUsed);
        
            Map<String,String> Gender = new HashMap<String,String>();

        
            Gender.put("男","2");

        
            Gender.put("女","3");

        
            publicDataDict.put("Gender", Gender);
        
            Map<String,String> JobTitle = new HashMap<String,String>();

        
            JobTitle.put("教授","2");

        
            JobTitle.put("主任医师","3");

        
            JobTitle.put("副教授","4");

        
            JobTitle.put("副主任医师","5");

        
            publicDataDict.put("JobTitle", JobTitle);
        
            Map<String,String> State = new HashMap<String,String>();

        
            State.put("使用","2");

        
            State.put("取消","3");

        
            State.put("过期","4");

        
            State.put("待使用","5");

        
            publicDataDict.put("State", State);
        
            Map<String,String> ScheduleStatus = new HashMap<String,String>();

        
            ScheduleStatus.put("进行中","2");

        
            ScheduleStatus.put("已结束","3");

        
            ScheduleStatus.put("未开始","4");

        
            publicDataDict.put("ScheduleStatus", ScheduleStatus);
        
	
	return publicDataDict; 
}
//保存文件
public  static String upload_path_handler(String modelName) {
    String now_time = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
    String str = String.format("upload/DHMSPro_p/DHMSPro",modelName,now_time);
    return str;
}
    
public static String  save_file(String modelName,HttpServletRequest  request,MultipartFile myfile ) throws IllegalStateException, IOException {
    //如果选择了上传文件，将文件上传到指定的目录images
        if(!myfile.isEmpty()) {
            //上传文件路径（生产环境）
            //String path = request.getServletContext().getRealPath("/images/");
            //获得上传文件原名
            //上传文件路径（开发环境）
            //String path = "C:\\workspace-spring-tool-suite-4-4.1.1.RELEASE\\eBusiness\\src\\main\\resources\\static\\images";
            String path = "D:\\lsy\\私人接单\\积累的程序\\自动生成代码\\SpringBoot\\JAVASpringBoot-商城\\boostrap\\程序及支持文件\\OSPro\\src\\main\\resources\\static\\images";
            //获得上传文件原名
            String fileName = myfile.getOriginalFilename();
            //对文件重命名
            String fileNewName = MyUtil.getNewFileName(fileName);
            String uploadPath = upload_path_handler(modelName);
            String showFileName = uploadPath +  File.separator + fileNewName;
            File filePath = new File(path + File.separator + showFileName);
            //如果文件目录不存在，创建目录
            if(!filePath.getParentFile().exists()) {
                filePath.getParentFile().mkdirs();
            }
            //将上传文件保存到一个目标文件中
            myfile.transferTo(filePath);
            //返回文件路径
            return showFileName;
        }
        else{
            return "";
        }
}
}
