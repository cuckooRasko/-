package com.ch.DHMSPro.service.before.MemberCenter.PC;
import java.util.List;

import javax.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;
import com.ch.DHMSPro.entity.Member;
import com.ch.DHMSPro.repository.before.MemberCenter.PC.MemberCenterPCUserRepository;
import com.ch.DHMSPro.util.MD5Util;
@Service("MemberCenterPCMemberUserServiceImpl")
public class UserServiceImpl implements UserService {
	@Autowired 
	private MemberCenterPCUserRepository userRepository;
	
	
	@Override
	public String login(Member member, HttpSession session, Model model) {
		//对密码MD5加密
		/*
		member.setBpwd(MD5Util.MD5(member.getBpwd()));
		String rand = (String)session.getAttribute("rand");
		if(!rand.equalsIgnoreCase(member.getCode())) {
			model.addAttribute("errorMessage", "验证码错误！");
			return "before/MemberCenter/tologin";
		}*/
		List<Member> list = userRepository.login(member);
		if(list.size() > 0) {
			session.setAttribute("member", list.get(0));
			session.setAttribute("frontusername", list.get(0).getName()); 
			session.setAttribute("frontusernameid", list.get(0).getId()); 
			return   "before/MemberCenter/index";//"redirect:/";//到首页
		}
		model.addAttribute("errorMessage", "用户名或密码错误！");
		return "before/MemberCenter/login";
	}
	@Override
	public String logout(Member member, HttpSession session, Model model) {
		session.setAttribute("member", null);
		session.setAttribute("frontusername", null);
		session.setAttribute("frontusernameid", null);
		return "before/MemberCenter/login";
		
	}
}
