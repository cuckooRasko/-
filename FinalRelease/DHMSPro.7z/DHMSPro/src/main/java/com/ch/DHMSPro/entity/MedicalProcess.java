package com.ch.DHMSPro.entity;

import org.springframework.web.multipart.MultipartFile;

public class MedicalProcess {
	
            private int Id;
        
            private String CreatedTime;
        
            private String UpdateTime;
        
            private int DepartmentId;
        
            private String Name;
        
            private int SerialNumber;
        
	
        public int getId() {
            return Id;
        }
        public void setId(int Id) {
            this.Id = Id;
        }
        
        public String getCreatedTime() {
            return CreatedTime;
        }
        public void setCreatedTime(String CreatedTime) {
            this.CreatedTime = CreatedTime;
        }
        
        public String getUpdateTime() {
            return UpdateTime;
        }
        public void setUpdateTime(String UpdateTime) {
            this.UpdateTime = UpdateTime;
        }
        
        public int getDepartmentId() {
            return DepartmentId;
        }
        public void setDepartmentId(int DepartmentId) {
            this.DepartmentId = DepartmentId;
        }
        
        public String getName() {
            return Name;
        }
        public void setName(String Name) {
            this.Name = Name;
        }
        
        public int getSerialNumber() {
            return SerialNumber;
        }
        public void setSerialNumber(int SerialNumber) {
            this.SerialNumber = SerialNumber;
        }
        
	
}
