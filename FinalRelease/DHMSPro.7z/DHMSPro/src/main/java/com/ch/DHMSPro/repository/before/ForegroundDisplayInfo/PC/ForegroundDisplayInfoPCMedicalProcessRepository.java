package com.ch.DHMSPro.repository.before.ForegroundDisplayInfo.PC;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.ch.DHMSPro.entity.MedicalProcess;

@Mapper
public interface ForegroundDisplayInfoPCMedicalProcessRepository {
	
        int update(MedicalProcess medicalprocess);
        
        MedicalProcess select(Integer id);
        
        List<Map> selectAllByPage(@Param("startIndex") int startIndex, @Param("perPageSize") int perPageSize,
        @Param("Name") String  Name
        );
        
        MedicalProcess selectByName(String Name);

        
        
        List<MedicalProcess> selectAllName();

        
        
        int selectAll(
        @Param("Name") String  Name
        );
        
        List<MedicalProcess> selectAllRecords();
        
	
}
