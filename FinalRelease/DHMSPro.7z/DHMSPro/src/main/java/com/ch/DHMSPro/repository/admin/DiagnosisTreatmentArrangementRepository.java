package com.ch.DHMSPro.repository.admin;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.ch.DHMSPro.entity.DiagnosisTreatmentArrangement;

@Mapper
public interface DiagnosisTreatmentArrangementRepository {
	int add(DiagnosisTreatmentArrangement diagnosistreatmentarrangement);
	int update(DiagnosisTreatmentArrangement diagnosistreatmentarrangement);
	int selectAll(
        @Param("DepartmentId") String  DepartmentId
        ,
        @Param("Name") String  Name
        ,
        @Param("StartingTime") String  StartingTime
        ,
        @Param("EndTime") String  EndTime
        );
	DiagnosisTreatmentArrangement select(Integer id);
	List<Map> selectAllByPage(@Param("startIndex") int startIndex, @Param("perPageSize") int perPageSize,
        @Param("DepartmentId") String  DepartmentId
        ,
        @Param("Name") String  Name
        ,
        @Param("StartingTime") String  StartingTime
        ,
        @Param("EndTime") String  EndTime
        );
	int  delete(Integer id);
	List<DiagnosisTreatmentArrangement> selectAllRecords();
	
	
        DiagnosisTreatmentArrangement selectByName(String Name);

        
	
        List<DiagnosisTreatmentArrangement> selectAllName();

        
	
}
