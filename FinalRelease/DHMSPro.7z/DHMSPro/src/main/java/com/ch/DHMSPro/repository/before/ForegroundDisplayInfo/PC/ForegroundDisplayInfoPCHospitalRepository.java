package com.ch.DHMSPro.repository.before.ForegroundDisplayInfo.PC;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.ch.DHMSPro.entity.Hospital;

@Mapper
public interface ForegroundDisplayInfoPCHospitalRepository {
	
        int update(Hospital hospital);
        
        Hospital select(Integer id);
        
        List<Map> selectAllByPage(@Param("startIndex") int startIndex, @Param("perPageSize") int perPageSize,
        @Param("Name") String  Name
        );
        
        Hospital selectByName(String Name);

        
        
        List<Hospital> selectAllName();

        
        
        int selectAll(
        @Param("Name") String  Name
        );
        
        List<Hospital> selectAllRecords();
        
	
}
