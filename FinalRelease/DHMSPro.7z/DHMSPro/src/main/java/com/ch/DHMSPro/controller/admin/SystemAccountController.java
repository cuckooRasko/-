package com.ch.DHMSPro.controller.admin;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.ch.DHMSPro.entity.SystemAccount;
import com.ch.DHMSPro.service.admin.SystemAccountService;

@Controller("SystemAccountController")
@RequestMapping("/admin/SystemAccount")
public class SystemAccountController extends AdminBaseController{
	@Autowired
	private SystemAccountService systemaccountService;
	@RequestMapping("/index")
	public String selectAllByPage(Model model, Integer currentPage, String act, HttpServletRequest  request) {
		return systemaccountService.selectAllByPage(model, currentPage, act,request);
	}
	@RequestMapping("/add")
	public String add(@ModelAttribute("systemaccount") SystemAccount systemaccount, Model model) {

		return systemaccountService.add(systemaccount, model);
	}
	@RequestMapping("/save_add")
	@ResponseBody
	public String save_add(@ModelAttribute("systemaccount") SystemAccount systemaccount, HttpServletRequest  request) throws IllegalStateException, IOException {
		return systemaccountService.save_add(systemaccount,request);
	}
	@RequestMapping("/edit")
	public String edit(Model model, Integer id) {

		return systemaccountService.edit(model, id);
	}
	@RequestMapping("/save_edit")
	@ResponseBody
	public String save_edit(@ModelAttribute("systemaccount") SystemAccount systemaccount, HttpServletRequest  request) throws IllegalStateException, IOException {
		return systemaccountService.save_edit(systemaccount, request);
	}
	@RequestMapping("/detail")
	public String detail(Model model, Integer id) {
		return systemaccountService.detail(model, id);
	}
	@RequestMapping("/delete")
	public String delete(Integer id) {
		return systemaccountService.delete(id);
	}
	/**
	 * 导入excel
	 */
	@RequestMapping("/importexcel")
	@ResponseBody
	public String importexcel(@ModelAttribute("systemaccount") SystemAccount systemaccount, HttpServletRequest  request) throws IllegalStateException,IOException {
		return systemaccountService.importexcel(systemaccount,request);
		
	}
}
