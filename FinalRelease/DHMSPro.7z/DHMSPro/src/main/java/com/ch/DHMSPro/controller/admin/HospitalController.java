package com.ch.DHMSPro.controller.admin;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.ch.DHMSPro.entity.Hospital;
import com.ch.DHMSPro.service.admin.HospitalService;

@Controller("HospitalController")
@RequestMapping("/admin/Hospital")
public class HospitalController extends AdminBaseController{
	@Autowired
	private HospitalService hospitalService;
	@RequestMapping("/index")
	public String selectAllByPage(Model model, Integer currentPage, String act, HttpServletRequest  request) {
		return hospitalService.selectAllByPage(model, currentPage, act,request);
	}
	@RequestMapping("/add")
	public String add(@ModelAttribute("hospital") Hospital hospital, Model model) {

		return hospitalService.add(hospital, model);
	}
	@RequestMapping("/save_add")
	@ResponseBody
	public String save_add(@ModelAttribute("hospital") Hospital hospital, HttpServletRequest  request) throws IllegalStateException, IOException {
		return hospitalService.save_add(hospital,request);
	}
	@RequestMapping("/edit")
	public String edit(Model model, Integer id) {

		return hospitalService.edit(model, id);
	}
	@RequestMapping("/save_edit")
	@ResponseBody
	public String save_edit(@ModelAttribute("hospital") Hospital hospital, HttpServletRequest  request) throws IllegalStateException, IOException {
		return hospitalService.save_edit(hospital, request);
	}
	@RequestMapping("/detail")
	public String detail(Model model, Integer id) {
		return hospitalService.detail(model, id);
	}
	@RequestMapping("/delete")
	public String delete(Integer id) {
		return hospitalService.delete(id);
	}
	/**
	 * 导入excel
	 */
	@RequestMapping("/importexcel")
	@ResponseBody
	public String importexcel(@ModelAttribute("hospital") Hospital hospital, HttpServletRequest  request) throws IllegalStateException,IOException {
		return hospitalService.importexcel(hospital,request);
		
	}
}
