package com.ch.DHMSPro.repository.admin;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.ch.DHMSPro.entity.SystemAccount;

@Mapper
public interface SystemAccountRepository {
	int add(SystemAccount systemaccount);
	int update(SystemAccount systemaccount);
	int selectAll(
        @Param("Name") String  Name
        );
	SystemAccount select(Integer id);
	List<Map> selectAllByPage(@Param("startIndex") int startIndex, @Param("perPageSize") int perPageSize,
        @Param("Name") String  Name
        );
	int  delete(Integer id);
	List<SystemAccount> selectAllRecords();
	
	
        SystemAccount selectByName(String Name);

        
	
        List<SystemAccount> selectAllName();

        
	
}
