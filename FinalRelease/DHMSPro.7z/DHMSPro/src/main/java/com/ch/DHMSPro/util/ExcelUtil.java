package com.ch.DHMSPro.util;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.web.multipart.MultipartFile;

import com.alibaba.excel.ExcelReader;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.DecimalFormat;
import java.util.*;
import java.util.logging.Logger;


/**
 * 读取Excel内容
 * @author Administrator
 *
 */

public class ExcelUtil {

    private static Logger logger = Logger.getLogger(ExcelReader.class.getName()); // 日志打印类
    //Map<String,Object> map = new HashMap<String, Object>();

    private static final String XLS = "xls";
    private static final String XLSX = "xlsx";

    /**
               * 根据文件后缀名类型获取对应的工作簿对象
     * @param inputStream 读取文件的输入流
     * @param fileType 文件后缀名类型（xls或xlsx）
     * @return 包含文件数据的工作簿对象
     * @throws IOException
     */
    public static Workbook getWorkbook(InputStream inputStream, String fileType) throws  Exception {
        //Workbook workbook = null;
       
        Workbook workbook = WorkbookFactory.create(inputStream);
       
        return workbook;
    }
    /**
     * 将单元格内容转换为字符串
     * @param cell
     * @return
     */
    private static String convertCellValueToString(Cell cell) {
        if(cell==null){
            return null;
        }
        String returnValue = null;
        switch (cell.getCellTypeEnum()) {
            case NUMERIC:   //数字
                Double doubleValue = cell.getNumericCellValue();

                // 格式化科学计数法，取一位整数
                DecimalFormat df = new DecimalFormat("0");
                returnValue = df.format(doubleValue);
                break;
            case STRING:    //字符串
                returnValue = cell.getStringCellValue();
                break;
            case BOOLEAN:   //布尔
                Boolean booleanValue = cell.getBooleanCellValue();
                returnValue = booleanValue.toString();
                break;
            case BLANK:     // 空值
                break;
            case FORMULA:   // 公式
                returnValue = cell.getCellFormula();
                break;
            case ERROR:     // 故障
                break;
            default:
                break;
        }
        return returnValue;
    }

    
    public static List<Map<String,String>> readExcelFile(MultipartFile file) {

        Workbook workbook = null;

        try {
            // 获取Excel后缀名
            String fileName = file.getOriginalFilename();
            if (fileName == null || fileName.isEmpty() || fileName.lastIndexOf(".") < 0) {
                logger.warning("解析Excel失败，因为获取到的Excel文件名非法！");
                return null;
            }
            String fileType = fileName.substring(fileName.lastIndexOf(".") + 1, fileName.length());
            
            // 获取Excel工作簿
            InputStream input = file.getInputStream();
            
            workbook = getWorkbook(input, fileType);

            // 读取excel中的数据
            List<Map<String,String>> resultDataList = parseExcelFile(workbook);
 
            return resultDataList;
        } catch (Exception e) {
        	System.out.println(e.getMessage());
            logger.warning("解析Excel失败，文件名：" + file.getOriginalFilename() + " 错误信息：" + e.getMessage());
            return null;
        } finally {
            try {
                if (null != workbook) {
                    workbook.close();
                }
            } catch (Exception e) {
            	System.out.println(e.getMessage());
                logger.warning("关闭数据流出错！错误信息：" + e.getMessage());
                return null;
            }
        }
    }


    /**
               * 解析Excel数据
     * @param workbook Excel工作簿对象
     * @return 解析结果
     */
    private static List<Map<String,String>> parseExcelFile(Workbook workbook) {
    	List<Map<String,String>> resultDataList = new ArrayList<>();
        System.out.println("parseExcel");
        System.out.println(workbook.getNumberOfSheets());
        // 解析sheet
        for (int sheetNum = 0; sheetNum < workbook.getNumberOfSheets(); sheetNum++) {
            Sheet sheet = workbook.getSheetAt(sheetNum);

            // 校验sheet是否合法
            if (sheet == null) {
                continue;
            }
            System.out.println(sheetNum);
            // 获取第一行数据
            //int firstRowNum = sheet.getFirstRowNum();
            int firstRowNum = 0;
            
            Row firstRow = sheet.getRow(firstRowNum);
            System.out.println(firstRow);
            //if (null == firstRow) {
                //logger.warning("解析Excel失败，在第一行没有读取到任何数据！");
            //}
           List<String> headColumns = new ArrayList<String>();
           if (! (null == firstRow)) {
            //logger.warning("解析Excel失败，在第一行没有读取到任何数据！");
        	   int cellNum = 0;
        	   Cell cell;
        	   while (true){
        		   cell = firstRow.getCell(cellNum++);
        	       String value = convertCellValueToString(cell);
        	       System.out.println(value);
        	       if (null == value || "".equals(value))
        	       {
        	    	   break;
        	       }
        	       else {
        	    	   
        	    	   headColumns.add(value);  
        	       }
        	   }
            }
            firstRowNum = sheet.getFirstRowNum();
            // 解析每一行的数据，构造数据对象
            int rowStart = firstRowNum + 1; //获取第几行
            int rowEnd = sheet.getPhysicalNumberOfRows();
            Map<String,String> resultData = new HashMap<String,String>();
            for (int rowNum = rowStart; rowNum < rowEnd; rowNum++) {
                Row row = sheet.getRow(rowNum);

                if (null == row) {
                    continue;
                }

                resultData = convertExcelRowToData(row,headColumns);
                if (null == resultData) {
                    logger.warning("第 " + row.getRowNum() + "行数据不合法，已忽略！");
                    continue;
                }
                resultDataList.add(resultData);
            }
        }

        return resultDataList;
    }


    /**
     * 提取每一行中需要的数据，构造成为一个结果数据对象
     *
     * 当该行中有单元格的数据为空或不合法时，忽略该行的数据
     *
     * @param row 行数据
     * @return 解析后的行数据对象，行数据错误时返回null
     */
    private static Map<String,String> convertExcelRowToData(Row row,List<String> headColumns) {
    	Map<String,String> resultData = new HashMap<String,String>();

        Cell cell;
        System.out.println(headColumns.size());
        if (!(null == row)) {
            //logger.warning("解析Excel失败，在第一行没有读取到任何数据！");
        	for (int cellNum = 0; cellNum < headColumns.size(); cellNum++){
        		   cell = row.getCell(cellNum);
        	       String value = convertCellValueToString(cell);
        	       resultData.put(headColumns.get(cellNum), value);
        	   }
            }

        return resultData;
    }

}
