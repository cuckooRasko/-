package com.ch.DHMSPro.service.before.DoctorCenter.PC;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;

import org.springframework.ui.Model;

import com.ch.DHMSPro.entity.DiagnosisTreatmentRegistered;

public interface DiagnosisTreatmentRegisteredService {
	    
        public String selectAllByPage(Model model, Integer currentPage, String act,HttpServletRequest  request);
        
        public String detail(Model model, Integer id);
        
}
