package com.ch.DHMSPro.entity;

import org.springframework.web.multipart.MultipartFile;

public class DiagnosisTreatmentMedicalRecord {
	
            private int Id;
        
            private String CreatedTime;
        
            private String UpdateTime;
        
            private int DiagnosisTreatmentRegisteredId;
        
            private int MedicalProcessId;
        
            private int DoctorId;
        
            private String DiagnosisTreatment;
        
            private String DiagnosisTreatmentMeasures;
        
	
        public int getId() {
            return Id;
        }
        public void setId(int Id) {
            this.Id = Id;
        }
        
        public String getCreatedTime() {
            return CreatedTime;
        }
        public void setCreatedTime(String CreatedTime) {
            this.CreatedTime = CreatedTime;
        }
        
        public String getUpdateTime() {
            return UpdateTime;
        }
        public void setUpdateTime(String UpdateTime) {
            this.UpdateTime = UpdateTime;
        }
        
        public int getDiagnosisTreatmentRegisteredId() {
            return DiagnosisTreatmentRegisteredId;
        }
        public void setDiagnosisTreatmentRegisteredId(int DiagnosisTreatmentRegisteredId) {
            this.DiagnosisTreatmentRegisteredId = DiagnosisTreatmentRegisteredId;
        }
        
        public int getMedicalProcessId() {
            return MedicalProcessId;
        }
        public void setMedicalProcessId(int MedicalProcessId) {
            this.MedicalProcessId = MedicalProcessId;
        }
        
        public int getDoctorId() {
            return DoctorId;
        }
        public void setDoctorId(int DoctorId) {
            this.DoctorId = DoctorId;
        }
        
        public String getDiagnosisTreatment() {
            return DiagnosisTreatment;
        }
        public void setDiagnosisTreatment(String DiagnosisTreatment) {
            this.DiagnosisTreatment = DiagnosisTreatment;
        }
        
        public String getDiagnosisTreatmentMeasures() {
            return DiagnosisTreatmentMeasures;
        }
        public void setDiagnosisTreatmentMeasures(String DiagnosisTreatmentMeasures) {
            this.DiagnosisTreatmentMeasures = DiagnosisTreatmentMeasures;
        }
        
	
}
