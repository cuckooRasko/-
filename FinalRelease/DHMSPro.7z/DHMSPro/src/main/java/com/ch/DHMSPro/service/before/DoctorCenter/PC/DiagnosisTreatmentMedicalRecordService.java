package com.ch.DHMSPro.service.before.DoctorCenter.PC;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;

import org.springframework.ui.Model;

import com.ch.DHMSPro.entity.DiagnosisTreatmentMedicalRecord;

public interface DiagnosisTreatmentMedicalRecordService {
	
        public String add(DiagnosisTreatmentMedicalRecord diagnosistreatmentmedicalrecord, Model model);
        
        public String save_add(DiagnosisTreatmentMedicalRecord diagnosistreatmentmedicalrecord, HttpServletRequest  request) throws IllegalStateException, IOException ;
        
        
        public String delete(Integer id);
        
        public String edit(Model model,Integer id);
        
        public String save_edit(DiagnosisTreatmentMedicalRecord diagnosistreatmentmedicalrecord, HttpServletRequest  request) throws IllegalStateException, IOException ;
            
        public String selectAllByPage(Model model, Integer currentPage, String act,HttpServletRequest  request);
        
        public String detail(Model model, Integer id);
        
}
