package com.ch.DHMSPro.entity;

import org.springframework.web.multipart.MultipartFile;

public class Hospital {
	
            private int Id;
        
            private String CreatedTime;
        
            private String UpdateTime;
        
            private String Name;
        
            private String Address;
        
            private String Telephone;
        
            private String URL;
        
            private String Introduction;
        
            private String Picture;
        
            private String Established;
        
	
        public int getId() {
            return Id;
        }
        public void setId(int Id) {
            this.Id = Id;
        }
        
        public String getCreatedTime() {
            return CreatedTime;
        }
        public void setCreatedTime(String CreatedTime) {
            this.CreatedTime = CreatedTime;
        }
        
        public String getUpdateTime() {
            return UpdateTime;
        }
        public void setUpdateTime(String UpdateTime) {
            this.UpdateTime = UpdateTime;
        }
        
        public String getName() {
            return Name;
        }
        public void setName(String Name) {
            this.Name = Name;
        }
        
        public String getAddress() {
            return Address;
        }
        public void setAddress(String Address) {
            this.Address = Address;
        }
        
        public String getTelephone() {
            return Telephone;
        }
        public void setTelephone(String Telephone) {
            this.Telephone = Telephone;
        }
        
        public String getURL() {
            return URL;
        }
        public void setURL(String URL) {
            this.URL = URL;
        }
        
        public String getIntroduction() {
            return Introduction;
        }
        public void setIntroduction(String Introduction) {
            this.Introduction = Introduction;
        }
        
        public String getPicture() {
            return Picture;
        }
        public void setPicture(String Picture) {
            this.Picture = Picture;
        }
        
        public String getEstablished() {
            return Established;
        }
        public void setEstablished(String Established) {
            this.Established = Established;
        }
        
	
}
