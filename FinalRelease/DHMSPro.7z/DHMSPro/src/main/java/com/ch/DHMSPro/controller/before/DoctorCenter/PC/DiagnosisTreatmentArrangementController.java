package com.ch.DHMSPro.controller.before.DoctorCenter.PC;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.ch.DHMSPro.entity.DiagnosisTreatmentArrangement;
import com.ch.DHMSPro.service.before.DoctorCenter.PC.DiagnosisTreatmentArrangementService;
@Controller("DoctorCenterPCDiagnosisTreatmentArrangementController")
@RequestMapping("/DoctorCenterPC/DiagnosisTreatmentArrangement")
public class DiagnosisTreatmentArrangementController {
	@Autowired
	private DiagnosisTreatmentArrangementService diagnosistreatmentarrangementService;
	
        @RequestMapping("/index")
        public String selectAllByPage(Model model, Integer currentPage, String act,HttpServletRequest  request) {
            return diagnosistreatmentarrangementService.selectAllByPage(model, currentPage, act,request);
        }
        
        @RequestMapping("/detail")
        public String detail(Model model, Integer id) {
            return diagnosistreatmentarrangementService.detail(model, id);
        }
        
	
}
