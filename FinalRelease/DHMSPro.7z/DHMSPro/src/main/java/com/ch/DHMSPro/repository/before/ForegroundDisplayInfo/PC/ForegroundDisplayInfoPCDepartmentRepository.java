package com.ch.DHMSPro.repository.before.ForegroundDisplayInfo.PC;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.ch.DHMSPro.entity.Department;

@Mapper
public interface ForegroundDisplayInfoPCDepartmentRepository {
	
        int update(Department department);
        
        Department select(Integer id);
        
        List<Map> selectAllByPage(@Param("startIndex") int startIndex, @Param("perPageSize") int perPageSize,
        @Param("Name") String  Name
        );
        
        Department selectByName(String Name);

        
        
        List<Department> selectAllName();

        
        
        int selectAll(
        @Param("Name") String  Name
        );
        
        List<Department> selectAllRecords();
        
	
}
