package com.ch.DHMSPro.controller.before.ForegroundDisplayInfo.PC;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.ch.DHMSPro.entity.Hospital;
import com.ch.DHMSPro.service.before.ForegroundDisplayInfo.PC.HospitalService;
@Controller("ForegroundDisplayInfoPCHospitalController")
@RequestMapping("/ForegroundDisplayInfoPC/Hospital")
public class HospitalController {
	@Autowired
	private HospitalService hospitalService;
	
        @RequestMapping("/edit")
        public String edit(Model model, Integer id) {

            return hospitalService.edit(model, id);
        }
        
        @RequestMapping("/save_edit")
        @ResponseBody
        public String save_edit(@ModelAttribute("hospital") Hospital hospital, HttpServletRequest  request) throws IllegalStateException, IOException {
            return hospitalService.save_edit(hospital, request);
        }
        
        @RequestMapping("/index")
        public String selectAllByPage(Model model, Integer currentPage, String act,HttpServletRequest  request) {
            return hospitalService.selectAllByPage(model, currentPage, act,request);
        }
        
        @RequestMapping("/detail")
        public String detail(Model model, Integer id) {
            return hospitalService.detail(model, id);
        }
        
	
}
