package com.ch.DHMSPro.service.before.MemberCenter.PC;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;

import org.springframework.ui.Model;

import com.ch.DHMSPro.entity.DiagnosisTreatmentRegistered;

public interface DiagnosisTreatmentRegisteredService {
	
        public String add(DiagnosisTreatmentRegistered diagnosistreatmentregistered, Model model);
        
        public String save_add(DiagnosisTreatmentRegistered diagnosistreatmentregistered, HttpServletRequest  request) throws IllegalStateException, IOException ;
        
        public String edit(Model model,Integer id);
        
        public String save_edit(DiagnosisTreatmentRegistered diagnosistreatmentregistered, HttpServletRequest  request) throws IllegalStateException, IOException ;
            
        public String selectAllByPage(Model model, Integer currentPage, String act,HttpServletRequest  request);
        
        public String detail(Model model, Integer id);
        
}
