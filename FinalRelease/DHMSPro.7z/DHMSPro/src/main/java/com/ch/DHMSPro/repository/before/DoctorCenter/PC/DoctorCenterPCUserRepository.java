package com.ch.DHMSPro.repository.before.DoctorCenter.PC;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.ch.DHMSPro.entity.Doctor;
@Mapper
public interface DoctorCenterPCUserRepository {
	public List<Doctor> login(Doctor doctor);
}
