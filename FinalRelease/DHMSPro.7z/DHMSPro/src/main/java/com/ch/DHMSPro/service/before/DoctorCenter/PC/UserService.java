package com.ch.DHMSPro.service.before.DoctorCenter.PC;

import javax.servlet.http.HttpSession;

import org.springframework.ui.Model;

import com.ch.DHMSPro.entity.Doctor;

public interface UserService {
	public String login(Doctor doctor, HttpSession session, Model model);
	public String logout(Doctor doctor, HttpSession session, Model model);
}
