package com.ch.DHMSPro.controller.admin;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.ch.DHMSPro.entity.SystemAccount;
import com.ch.DHMSPro.service.admin.AdminService;

@Controller
@RequestMapping("/admin")
public class AdminController {
	@Autowired
	private AdminService adminService;
	@RequestMapping("/toLogin")
	public String toLogin(@ModelAttribute("systemAccount") SystemAccount systemAccount) {
		return "admin/Login/login";
	}
	@RequestMapping("/login")
	public String login(@ModelAttribute("systemAccount") SystemAccount systemAccount, HttpSession session, Model model) {
		return adminService.login(systemAccount, session, model);
	}
	@RequestMapping("/logout")
	public String logout(@ModelAttribute("systemAccount") SystemAccount systemAccount, HttpSession session, Model model) {
		return adminService.logout(systemAccount, session, model);
	}
}
