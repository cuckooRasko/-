package com.ch.DHMSPro.entity;

import org.springframework.web.multipart.MultipartFile;

public class Doctor {
	
            private int Id;
        
            private String CreatedTime;
        
            private String UpdateTime;
        
            private int DepartmentId;
        
            private String Name;
        
            private String Expertise;
        
            private String JobTitle;
        
            private String Introduction;
        
            private String Picture;
        
            private String PhoneNumber;
        
            private String Nickname;
        
            private String AvatarPicture;
        
            private MultipartFile AvatarPictureAvatarPictureFile;
        
            private String Password;
        
            private String Email;
        
            private String NameSurname;
        
            private String Gender;
        
	
        public int getId() {
            return Id;
        }
        public void setId(int Id) {
            this.Id = Id;
        }
        
        public String getCreatedTime() {
            return CreatedTime;
        }
        public void setCreatedTime(String CreatedTime) {
            this.CreatedTime = CreatedTime;
        }
        
        public String getUpdateTime() {
            return UpdateTime;
        }
        public void setUpdateTime(String UpdateTime) {
            this.UpdateTime = UpdateTime;
        }
        
        public int getDepartmentId() {
            return DepartmentId;
        }
        public void setDepartmentId(int DepartmentId) {
            this.DepartmentId = DepartmentId;
        }
        
        public String getName() {
            return Name;
        }
        public void setName(String Name) {
            this.Name = Name;
        }
        
        public String getExpertise() {
            return Expertise;
        }
        public void setExpertise(String Expertise) {
            this.Expertise = Expertise;
        }
        
        public String getJobTitle() {
            return JobTitle;
        }
        public void setJobTitle(String JobTitle) {
            this.JobTitle = JobTitle;
        }
        
        public String getIntroduction() {
            return Introduction;
        }
        public void setIntroduction(String Introduction) {
            this.Introduction = Introduction;
        }
        
        public String getPicture() {
            return Picture;
        }
        public void setPicture(String Picture) {
            this.Picture = Picture;
        }
        
        public String getPhoneNumber() {
            return PhoneNumber;
        }
        public void setPhoneNumber(String PhoneNumber) {
            this.PhoneNumber = PhoneNumber;
        }
        
        public String getNickname() {
            return Nickname;
        }
        public void setNickname(String Nickname) {
            this.Nickname = Nickname;
        }
        
        public String getAvatarPicture() {
            return AvatarPicture;
        }
        public void setAvatarPicture(String AvatarPicture) {
            this.AvatarPicture = AvatarPicture;
        }
        
        public MultipartFile getAvatarPictureAvatarPictureFile() {
            return AvatarPictureAvatarPictureFile;
        }
        public void setAvatarPictureAvatarPictureFile(MultipartFile AvatarPictureAvatarPictureFile) {
            this.AvatarPictureAvatarPictureFile = AvatarPictureAvatarPictureFile;
        }
        
        public String getPassword() {
            return Password;
        }
        public void setPassword(String Password) {
            this.Password = Password;
        }
        
        public String getEmail() {
            return Email;
        }
        public void setEmail(String Email) {
            this.Email = Email;
        }
        
        public String getNameSurname() {
            return NameSurname;
        }
        public void setNameSurname(String NameSurname) {
            this.NameSurname = NameSurname;
        }
        
        public String getGender() {
            return Gender;
        }
        public void setGender(String Gender) {
            this.Gender = Gender;
        }
        
	
}
