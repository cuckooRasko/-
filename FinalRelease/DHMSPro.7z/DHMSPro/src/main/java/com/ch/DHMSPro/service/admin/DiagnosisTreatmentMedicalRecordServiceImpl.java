package com.ch.DHMSPro.service.admin;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.tomcat.util.http.fileupload.servlet.ServletFileUpload;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.util.WebUtils;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.stream.Collectors;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ch.DHMSPro.entity.DiagnosisTreatmentMedicalRecord;
import com.ch.DHMSPro.repository.admin.DiagnosisTreatmentMedicalRecordRepository;
import com.ch.DHMSPro.util.MyUtil;
import com.ch.DHMSPro.util.ExcelUtil;
import com.ch.DHMSPro.util.utlitComm;

import com.ch.DHMSPro.repository.admin.DiagnosisTreatmentRegisteredRepository;
        
import com.ch.DHMSPro.repository.admin.MedicalProcessRepository;
        
import com.ch.DHMSPro.repository.admin.DoctorRepository;
        

import com.ch.DHMSPro.entity.DiagnosisTreatmentRegistered;        

        
import com.ch.DHMSPro.entity.MedicalProcess;        

        
import com.ch.DHMSPro.entity.Doctor;        

        
@Service("DiagnosisTreatmentMedicalRecordServiceImpl")
public class DiagnosisTreatmentMedicalRecordServiceImpl implements DiagnosisTreatmentMedicalRecordService{
	@Autowired
	private DiagnosisTreatmentMedicalRecordRepository diagnosistreatmentmedicalrecordRepository;
	
        @Autowired
        private DiagnosisTreatmentRegisteredRepository diagnosistreatmentregisteredRepository;
        
        @Autowired
        private MedicalProcessRepository medicalprocessRepository;
        
        @Autowired
        private DoctorRepository doctorRepository;
        
	@Override
	public String selectAllByPage(Model model,Integer currentPage, String act,HttpServletRequest  request) {
		Map<String,String>  searchFieldAndContent = getAllRequestParam(request);
		
		//共多少个商品
	  	int totalCount = diagnosistreatmentmedicalrecordRepository.selectAll(    
        searchFieldAndContent.get("DiagnosisTreatmentRegisteredId")  
        );
	  	//计算共多少页
	  	int pageSize = 5;
		if (currentPage == null) {
	  		currentPage = 1;
	  	}
	  	int totalPage = (int)Math.ceil(totalCount*1.0/pageSize);
	  	List<Map> curPageObject = diagnosistreatmentmedicalrecordRepository.selectAllByPage((currentPage-1)*pageSize, pageSize,    
        searchFieldAndContent.get("DiagnosisTreatmentRegisteredId")  
        );
		
		
        List<DiagnosisTreatmentRegistered> DiagnosisTreatmentRegisteredList = diagnosistreatmentregisteredRepository.selectAllName();
        model.addAttribute("DiagnosisTreatmentRegisteredList", DiagnosisTreatmentRegisteredList);
        
        List<MedicalProcess> MedicalProcessList = medicalprocessRepository.selectAllName();
        model.addAttribute("MedicalProcessList", MedicalProcessList);
        
        List<Doctor> DoctorList = doctorRepository.selectAllName();
        model.addAttribute("DoctorList", DoctorList);
        
		model.addAttribute("DiagnosisTreatmentMedicalRecord", searchFieldAndContent);
 		model.addAttribute("curPageObject", curPageObject );
	    	model.addAttribute("totalPage", totalPage);
	    	model.addAttribute("currentPage", currentPage);
	    	model.addAttribute("act", act);
		return "admin/DiagnosisTreatmentMedicalRecord/index";
	}

	@Override
	public String save_add(DiagnosisTreatmentMedicalRecord diagnosistreatmentmedicalrecord, HttpServletRequest  request) throws IllegalStateException, IOException {
			
		int n = diagnosistreatmentmedicalrecordRepository.add(diagnosistreatmentmedicalrecord);
		if(n > 0)//成功
			return "/admin/DiagnosisTreatmentMedicalRecord/index?currentPage=1&act=select";
			//失败
		return "fail";//"admin/DiagnosisTreatmentMedicalRecord/add";
		
	}
	@Override
	public String save_edit(DiagnosisTreatmentMedicalRecord diagnosistreatmentmedicalrecord, HttpServletRequest  request) throws IllegalStateException, IOException {
			
		int n = diagnosistreatmentmedicalrecordRepository.update(diagnosistreatmentmedicalrecord);
		if(n > 0)//成功
			return "/admin/DiagnosisTreatmentMedicalRecord/index?currentPage=1&act=updateSelect";
			//失败
		return  "fail";//"admin/DiagnosisTreatmentMedicalRecord/edit";	
	}
	@Override
	public String add(DiagnosisTreatmentMedicalRecord diagnosistreatmentmedicalrecord, Model model) {
		
        model.addAttribute("DiagnosisTreatmentRegistered", diagnosistreatmentregisteredRepository.selectAllRecords());
        
        model.addAttribute("MedicalProcess", medicalprocessRepository.selectAllRecords());
        
        model.addAttribute("Doctor", doctorRepository.selectAllRecords());
        
		return "admin/DiagnosisTreatmentMedicalRecord/add";
	}
	@Override
	public String edit(Model model,Integer id) {
		
        model.addAttribute("DiagnosisTreatmentRegistered", diagnosistreatmentregisteredRepository.selectAllRecords());
        
        model.addAttribute("MedicalProcess", medicalprocessRepository.selectAllRecords());
        
        model.addAttribute("Doctor", doctorRepository.selectAllRecords());
        
		model.addAttribute("diagnosistreatmentmedicalrecord", diagnosistreatmentmedicalrecordRepository.select(id));
		return "admin/DiagnosisTreatmentMedicalRecord/edit";
	}
	@Override
	public String detail(Model model, Integer id) {
		model.addAttribute("diagnosistreatmentmedicalrecord", diagnosistreatmentmedicalrecordRepository.select(id));
		return "admin/DiagnosisTreatmentMedicalRecord/detail";		
	}

	@Override
	public String delete(Integer id) {
		
		diagnosistreatmentmedicalrecordRepository.delete(id);
		return "redirect:/admin/DiagnosisTreatmentMedicalRecord/index?currentPage=1&act=deleteSelect";
		
	}

	
        private String processFileUpload(MultipartFile myfile,HttpServletRequest  request) throws IllegalStateException, IOException {
    	String fileNewName = "";
    	System.out.println(myfile !=null);
    	
    	if(myfile !=null && !myfile.isEmpty()) {
			//上传文件路径（生产环境）
			String path = request.getServletContext().getRealPath("/images/");
			//获得上传文件原名
			//上传文件路径（开发环境）
			
			String fileName = myfile.getOriginalFilename();
			//对文件重命名
			fileNewName = MyUtil.getNewFileName(fileName);
			File filePath = new File(path + File.separator + fileNewName);
			//如果文件目录不存在，创建目录
			if(!filePath.getParentFile().exists()) {
				filePath.getParentFile().mkdirs();
			}
			//将上传文件保存到一个目标文件中
			myfile.transferTo(filePath);

		}
    	return fileNewName;
    }
    /*
    * 获取客户端请求参数中所有的信息
    * @param request
    * @return
    */
   private Map<String, String> getAllRequestParam(final HttpServletRequest request) {
       Map<String, String> res = new HashMap<String, String>();
       Enumeration<?> temp = request.getParameterNames();
       if (null != temp) {
           while (temp.hasMoreElements()) {
               String en = (String) temp.nextElement();
               String value = request.getParameter(en);
               res.put(en, value);
               //如果字段的值为空，判断若值为空，则删除这个字段>
               //if (null == res.get(en) || "".equals(res.get(en))) {
                   //res.remove(en);
               //}
           }
       }
       return res;
   }
   private String updateFileField(HttpServletRequest  request,String fileFieldName) throws IllegalStateException, IOException {		
		MultipartFile file = null;
		String fileNewName = "";
		boolean isMultipart = ServletFileUpload.isMultipartContent(request);
		if (isMultipart){
		    MultipartHttpServletRequest multipartRequest =
		    WebUtils.getNativeRequest(request,MultipartHttpServletRequest.class);
		    file = multipartRequest.getFile(fileFieldName);
		    if (!(file == null))
		    {
		    	fileNewName = processFileUpload(file,request);		    	
		    }   	
		}
		return fileNewName;
		
   }

              @Override
	public String importexcel(DiagnosisTreatmentMedicalRecord diagnosistreatmentmedicalrecord,HttpServletRequest  request) throws IllegalStateException, IOException {
		try {	
	   		
			MultipartFile file = null;
			String fileFieldName = "uploadExcelFile";
			boolean isMultipart = ServletFileUpload.isMultipartContent(request);
			if (isMultipart){
			    MultipartHttpServletRequest multipartRequest =
			    WebUtils.getNativeRequest(request,MultipartHttpServletRequest.class);
			    MultipartFile myfile = multipartRequest.getFile(fileFieldName);
			    String fileName = myfile.getOriginalFilename();
			    
			    List<Map<String,String>> readFileResult = ExcelUtil.readExcelFile(myfile); //excel读取到的数据
			    System.out.println(readFileResult);
			    DiagnosisTreatmentMedicalRecord diagnosistreatmentmedicalrecordTemp = new DiagnosisTreatmentMedicalRecord();
			    
                            DiagnosisTreatmentRegistered diagnosistreatmentregistered = new DiagnosisTreatmentRegistered();
        
                            MedicalProcess medicalprocess = new MedicalProcess();
        
                            Doctor doctor = new Doctor();
        
			    Map<String, Map<String, String>> publicDict = utlitComm.publicDict();
			    
			    Map<String,String> rowData =  new HashMap<String,String>();
			    for (int i=0;i<readFileResult.size();i++){
			    	rowData = readFileResult.get(i);
			    	for(String key : rowData.keySet()){
			    		   String value = rowData.get(key);
					   
                            if (key.equals("CreatedTime")) {
                               diagnosistreatmentmedicalrecordTemp.setCreatedTime(value);
                            }
        
                           else  if (key.equals("UpdateTime")) {
                               diagnosistreatmentmedicalrecordTemp.setUpdateTime(value);
                            }
        
                          else  if (key.equals("DiagnosisTreatmentRegisteredId")) {
                                int DiagnosisTreatmentRegisteredId = 0;
                                
                                diagnosistreatmentregistered = diagnosistreatmentregisteredRepository.selectByName(value);
                                if (diagnosistreatmentregistered != null) {
                                    DiagnosisTreatmentRegisteredId = diagnosistreatmentregistered.getId();
                                }
                                else
                                {
                                        //新增
                                        diagnosistreatmentregistered = new DiagnosisTreatmentRegistered();
                                        diagnosistreatmentregistered.setName(value);
                                        DiagnosisTreatmentRegisteredId = diagnosistreatmentregisteredRepository.add(diagnosistreatmentregistered);
                                        DiagnosisTreatmentRegisteredId = diagnosistreatmentregisteredRepository.selectByName(value).getId();
                                }
                               diagnosistreatmentmedicalrecordTemp.setDiagnosisTreatmentRegisteredId(DiagnosisTreatmentRegisteredId);
                            }

        
                          else  if (key.equals("MedicalProcessId")) {
                                int MedicalProcessId = 0;
                                
                                medicalprocess = medicalprocessRepository.selectByName(value);
                                if (medicalprocess != null) {
                                    MedicalProcessId = medicalprocess.getId();
                                }
                                else
                                {
                                        //新增
                                        medicalprocess = new MedicalProcess();
                                        medicalprocess.setName(value);
                                        MedicalProcessId = medicalprocessRepository.add(medicalprocess);
                                        MedicalProcessId = medicalprocessRepository.selectByName(value).getId();
                                }
                               diagnosistreatmentmedicalrecordTemp.setMedicalProcessId(MedicalProcessId);
                            }

        
                          else  if (key.equals("DoctorId")) {
                                int DoctorId = 0;
                                
                                doctor = doctorRepository.selectByName(value);
                                if (doctor != null) {
                                    DoctorId = doctor.getId();
                                }
                                else
                                {
                                        //新增
                                        doctor = new Doctor();
                                        doctor.setName(value);
                                        DoctorId = doctorRepository.add(doctor);
                                        DoctorId = doctorRepository.selectByName(value).getId();
                                }
                               diagnosistreatmentmedicalrecordTemp.setDoctorId(DoctorId);
                            }

        
                           else  if (key.equals("DiagnosisTreatment")) {
                               diagnosistreatmentmedicalrecordTemp.setDiagnosisTreatment(value);
                            }
        
                           else  if (key.equals("DiagnosisTreatmentMeasures")) {
                               diagnosistreatmentmedicalrecordTemp.setDiagnosisTreatmentMeasures(value);
                            }
         
			    	}
			    	diagnosistreatmentmedicalrecordRepository.add(diagnosistreatmentmedicalrecordTemp); //添加入库
			    	diagnosistreatmentmedicalrecordTemp = new DiagnosisTreatmentMedicalRecord();
			    	

			    }
			return "ok";
			}
			else {
				return "数据文件不存在";
			}
		}catch (Exception e) {
			e.printStackTrace();
			return "数据导入失败，请规范导入模板";
		}
		
	}

}
