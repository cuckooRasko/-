package com.ch.DHMSPro.entity;

import org.springframework.web.multipart.MultipartFile;

public class Department {
	
            private int Id;
        
            private String CreatedTime;
        
            private String UpdateTime;
        
            private String Name;
        
            private String Introduction;
        
            private String Picture;
        
	
        public int getId() {
            return Id;
        }
        public void setId(int Id) {
            this.Id = Id;
        }
        
        public String getCreatedTime() {
            return CreatedTime;
        }
        public void setCreatedTime(String CreatedTime) {
            this.CreatedTime = CreatedTime;
        }
        
        public String getUpdateTime() {
            return UpdateTime;
        }
        public void setUpdateTime(String UpdateTime) {
            this.UpdateTime = UpdateTime;
        }
        
        public String getName() {
            return Name;
        }
        public void setName(String Name) {
            this.Name = Name;
        }
        
        public String getIntroduction() {
            return Introduction;
        }
        public void setIntroduction(String Introduction) {
            this.Introduction = Introduction;
        }
        
        public String getPicture() {
            return Picture;
        }
        public void setPicture(String Picture) {
            this.Picture = Picture;
        }
        
	
}
