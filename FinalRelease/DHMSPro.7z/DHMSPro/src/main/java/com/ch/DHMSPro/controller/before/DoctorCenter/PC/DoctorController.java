package com.ch.DHMSPro.controller.before.DoctorCenter.PC;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.ch.DHMSPro.entity.Doctor;
import com.ch.DHMSPro.service.before.DoctorCenter.PC.DoctorService;
@Controller("DoctorCenterPCDoctorController")
@RequestMapping("/DoctorCenterPC/Doctor")
public class DoctorController {
	@Autowired
	private DoctorService doctorService;
	
        @RequestMapping("/edit")
        public String edit(Model model, Integer id) {

            return doctorService.edit(model, id);
        }
        
        @RequestMapping("/save_edit")
        @ResponseBody
        public String save_edit(@ModelAttribute("doctor") Doctor doctor, HttpServletRequest  request) throws IllegalStateException, IOException {
            return doctorService.save_edit(doctor, request);
        }
        
	
}
