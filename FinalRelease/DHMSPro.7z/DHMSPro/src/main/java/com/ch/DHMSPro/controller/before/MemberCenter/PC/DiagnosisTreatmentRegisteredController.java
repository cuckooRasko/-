package com.ch.DHMSPro.controller.before.MemberCenter.PC;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.ch.DHMSPro.entity.DiagnosisTreatmentRegistered;
import com.ch.DHMSPro.service.before.MemberCenter.PC.DiagnosisTreatmentRegisteredService;
@Controller("MemberCenterPCDiagnosisTreatmentRegisteredController")
@RequestMapping("/MemberCenterPC/DiagnosisTreatmentRegistered")
public class DiagnosisTreatmentRegisteredController {
	@Autowired
	private DiagnosisTreatmentRegisteredService diagnosistreatmentregisteredService;
	
        @RequestMapping("/add")
        public String add(@ModelAttribute("diagnosistreatmentregistered") DiagnosisTreatmentRegistered diagnosistreatmentregistered, Model model) {

            return diagnosistreatmentregisteredService.add(diagnosistreatmentregistered, model);
        }
        
        @RequestMapping("/save_add")
        @ResponseBody
        public String save_add(@ModelAttribute("diagnosistreatmentregistered") DiagnosisTreatmentRegistered diagnosistreatmentregistered, HttpServletRequest  request) throws IllegalStateException, IOException {
            return diagnosistreatmentregisteredService.save_add(diagnosistreatmentregistered,request);
        }
        
        @RequestMapping("/edit")
        public String edit(Model model, Integer id) {

            return diagnosistreatmentregisteredService.edit(model, id);
        }
        
        @RequestMapping("/save_edit")
        @ResponseBody
        public String save_edit(@ModelAttribute("diagnosistreatmentregistered") DiagnosisTreatmentRegistered diagnosistreatmentregistered, HttpServletRequest  request) throws IllegalStateException, IOException {
            return diagnosistreatmentregisteredService.save_edit(diagnosistreatmentregistered, request);
        }
        
        @RequestMapping("/index")
        public String selectAllByPage(Model model, Integer currentPage, String act,HttpServletRequest  request) {
            return diagnosistreatmentregisteredService.selectAllByPage(model, currentPage, act,request);
        }
        
        @RequestMapping("/detail")
        public String detail(Model model, Integer id) {
            return diagnosistreatmentregisteredService.detail(model, id);
        }
        
	
}
