package com.ch.DHMSPro.repository.before.DoctorCenter.PC;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.ch.DHMSPro.entity.Doctor;

@Mapper
public interface DoctorCenterPCDoctorRepository {
	
        int update(Doctor doctor);
        
        Doctor select(Integer id);
        
	
}
