package com.ch.DHMSPro.service.before.ForegroundDisplayInfo.PC;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.tomcat.util.http.fileupload.servlet.ServletFileUpload;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.util.WebUtils;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.stream.Collectors;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.ch.DHMSPro.entity.MedicalProcess;
import com.ch.DHMSPro.repository.before.ForegroundDisplayInfo.PC.ForegroundDisplayInfoPCMedicalProcessRepository;
import com.ch.DHMSPro.util.MyUtil;
import com.ch.DHMSPro.util.ExcelUtil;
import com.ch.DHMSPro.util.utlitComm;

import com.ch.DHMSPro.repository.admin.DepartmentRepository;
        

import com.ch.DHMSPro.entity.Department;        

        

@Service("ForegroundDisplayInfoPCMedicalProcessServiceImpl")
public class MedicalProcessServiceImpl implements MedicalProcessService{
	@Autowired
	private ForegroundDisplayInfoPCMedicalProcessRepository medicalprocessRepository;
	
        @Autowired
        private DepartmentRepository departmentRepository;
        
	
        @Override
        public String edit(Model model,Integer id) {
            
        model.addAttribute("Department", departmentRepository.selectAllRecords());
        
            model.addAttribute("medicalprocess", medicalprocessRepository.select(id));
            return "before/ForegroundDisplayInfo/MedicalProcess/edit";
        }
        
        @Override
        public String save_edit(MedicalProcess medicalprocess, HttpServletRequest  request) throws IllegalStateException, IOException {
                
            int n = medicalprocessRepository.update(medicalprocess);
            if(n > 0)//成功
                return "/before/ForegroundDisplayInfo/MedicalProcess/index?currentPage=1&act=updateSelect";
                //失败
            return  "fail";//"admin/MedicalProcess/edit";  
        }
            
       @Override
    public String selectAllByPage(Model model,Integer currentPage, String act,HttpServletRequest  request) {
        Map<String,String>  searchFieldAndContent = getAllRequestParam(request);
        
        //共多少个商品
        int totalCount = medicalprocessRepository.selectAll(    
        searchFieldAndContent.get("Name")  
        );
        //计算共多少页
        int pageSize = 5;
        if (currentPage == null) {
            currentPage = 1;
        }
        int totalPage = (int)Math.ceil(totalCount*1.0/pageSize);
        List<Map> curPageObject = medicalprocessRepository.selectAllByPage((currentPage-1)*pageSize, pageSize,    
        searchFieldAndContent.get("Name")  
        );
        
        
        List<Department> DepartmentList = departmentRepository.selectAllName();
        model.addAttribute("DepartmentList", DepartmentList);
        
        model.addAttribute("MedicalProcess", searchFieldAndContent);
        model.addAttribute("curPageObject", curPageObject );
            model.addAttribute("totalPage", totalPage);
            model.addAttribute("currentPage", currentPage);
            model.addAttribute("act", act);
        return "before/ForegroundDisplayInfo/MedicalProcess/index";
    }
        
        @Override
        public String detail(Model model, Integer id) {
            model.addAttribute("medicalprocess", medicalprocessRepository.select(id));
            return "before/ForegroundDisplayInfo/MedicalProcess/detail";      
        }
        

        private String processFileUpload(MultipartFile myfile,HttpServletRequest  request) throws IllegalStateException, IOException {
    	String fileNewName = "";
    	System.out.println(myfile !=null);
    	
    	if(myfile !=null && !myfile.isEmpty()) {
			//上传文件路径（生产环境）
			String path = request.getServletContext().getRealPath("/images/");
			//获得上传文件原名
			//上传文件路径（开发环境）
			
			String fileName = myfile.getOriginalFilename();
			//对文件重命名
			fileNewName = MyUtil.getNewFileName(fileName);
			File filePath = new File(path + File.separator + fileNewName);
			//如果文件目录不存在，创建目录
			if(!filePath.getParentFile().exists()) {
				filePath.getParentFile().mkdirs();
			}
			//将上传文件保存到一个目标文件中
			myfile.transferTo(filePath);

		}
    	return fileNewName;
    }
    /*
    * 获取客户端请求参数中所有的信息
    * @param request
    * @return
    */
   private Map<String, String> getAllRequestParam(final HttpServletRequest request) {
       Map<String, String> res = new HashMap<String, String>();
       Enumeration<?> temp = request.getParameterNames();
       if (null != temp) {
           while (temp.hasMoreElements()) {
               String en = (String) temp.nextElement();
               String value = request.getParameter(en);
               res.put(en, value);
               //如果字段的值为空，判断若值为空，则删除这个字段>
               //if (null == res.get(en) || "".equals(res.get(en))) {
                   //res.remove(en);
               //}
           }
       }
       return res;
   }
   private String updateFileField(HttpServletRequest  request,String fileFieldName) throws IllegalStateException, IOException {		
		MultipartFile file = null;
		String fileNewName = "";
		boolean isMultipart = ServletFileUpload.isMultipartContent(request);
		if (isMultipart){
		    MultipartHttpServletRequest multipartRequest =
		    WebUtils.getNativeRequest(request,MultipartHttpServletRequest.class);
		    file = multipartRequest.getFile(fileFieldName);
		    if (!(file == null))
		    {
		    	fileNewName = processFileUpload(file,request);		    	
		    }   	
		}
		return fileNewName;
		
   }

}
