package com.ch.DHMSPro.controller.before.MemberCenter.PC;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.ch.DHMSPro.entity.DiagnosisTreatmentMedicalRecord;
import com.ch.DHMSPro.service.before.MemberCenter.PC.DiagnosisTreatmentMedicalRecordService;
@Controller("MemberCenterPCDiagnosisTreatmentMedicalRecordController")
@RequestMapping("/MemberCenterPC/DiagnosisTreatmentMedicalRecord")
public class DiagnosisTreatmentMedicalRecordController {
	@Autowired
	private DiagnosisTreatmentMedicalRecordService diagnosistreatmentmedicalrecordService;
	
        @RequestMapping("/index")
        public String selectAllByPage(Model model, Integer currentPage, String act,HttpServletRequest  request) {
            return diagnosistreatmentmedicalrecordService.selectAllByPage(model, currentPage, act,request);
        }
        
        @RequestMapping("/detail")
        public String detail(Model model, Integer id) {
            return diagnosistreatmentmedicalrecordService.detail(model, id);
        }
        
	
}
