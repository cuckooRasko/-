package com.ch.DHMSPro.service.before.FrontEnd.PC;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;

import org.springframework.ui.Model;

import com.ch.DHMSPro.entity.Member;

public interface MemberService {
	
        public String add(Member member, Model model);
        
        public String save_add(Member member, HttpServletRequest  request) throws IllegalStateException, IOException ;
        
}
