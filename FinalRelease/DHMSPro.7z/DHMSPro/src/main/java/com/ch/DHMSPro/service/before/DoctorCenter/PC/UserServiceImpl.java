package com.ch.DHMSPro.service.before.DoctorCenter.PC;
import java.util.List;

import javax.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;
import com.ch.DHMSPro.entity.Doctor;
import com.ch.DHMSPro.repository.before.DoctorCenter.PC.DoctorCenterPCUserRepository;
import com.ch.DHMSPro.util.MD5Util;
@Service("DoctorCenterPCDoctorUserServiceImpl")
public class UserServiceImpl implements UserService {
	@Autowired 
	private DoctorCenterPCUserRepository userRepository;
	
	@Override
	public String login(Doctor doctor, HttpSession session, Model model) {
		//对密码MD5加密
		/*
		doctor.setBpwd(MD5Util.MD5(doctor.getBpwd()));
		String rand = (String)session.getAttribute("rand");
		if(!rand.equalsIgnoreCase(doctor.getCode())) {
			model.addAttribute("errorMessage", "验证码错误！");
			return "before/DoctorCenter/tologin";
		}*/
		List<Doctor> list = userRepository.login(doctor);
		if(list.size() > 0) {
			session.setAttribute("doctor", list.get(0));
			session.setAttribute("frontusername", list.get(0).getName()); 
			return   "before/DoctorCenter/index";//"redirect:/";//到首页
		}
		model.addAttribute("errorMessage", "用户名或密码错误！");
		return "DoctorCenter/tologin";
	}
	@Override
	public String logout(Doctor doctor, HttpSession session, Model model) {
		session.setAttribute("doctor", null);
		return "before/DoctorCenter/tologin";
		
	}

}
