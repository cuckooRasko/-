package com.ch.DHMSPro.controller.admin;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.ch.DHMSPro.entity.Department;
import com.ch.DHMSPro.service.admin.DepartmentService;

@Controller("DepartmentController")
@RequestMapping("/admin/Department")
public class DepartmentController extends AdminBaseController{
	@Autowired
	private DepartmentService departmentService;
	@RequestMapping("/index")
	public String selectAllByPage(Model model, Integer currentPage, String act, HttpServletRequest  request) {
		return departmentService.selectAllByPage(model, currentPage, act,request);
	}
	@RequestMapping("/add")
	public String add(@ModelAttribute("department") Department department, Model model) {

		return departmentService.add(department, model);
	}
	@RequestMapping("/save_add")
	@ResponseBody
	public String save_add(@ModelAttribute("department") Department department, HttpServletRequest  request) throws IllegalStateException, IOException {
		return departmentService.save_add(department,request);
	}
	@RequestMapping("/edit")
	public String edit(Model model, Integer id) {

		return departmentService.edit(model, id);
	}
	@RequestMapping("/save_edit")
	@ResponseBody
	public String save_edit(@ModelAttribute("department") Department department, HttpServletRequest  request) throws IllegalStateException, IOException {
		return departmentService.save_edit(department, request);
	}
	@RequestMapping("/detail")
	public String detail(Model model, Integer id) {
		return departmentService.detail(model, id);
	}
	@RequestMapping("/delete")
	public String delete(Integer id) {
		return departmentService.delete(id);
	}
	/**
	 * 导入excel
	 */
	@RequestMapping("/importexcel")
	@ResponseBody
	public String importexcel(@ModelAttribute("department") Department department, HttpServletRequest  request) throws IllegalStateException,IOException {
		return departmentService.importexcel(department,request);
		
	}
}
