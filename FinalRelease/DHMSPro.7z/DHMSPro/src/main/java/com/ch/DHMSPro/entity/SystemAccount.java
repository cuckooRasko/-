package com.ch.DHMSPro.entity;

import org.springframework.web.multipart.MultipartFile;

public class SystemAccount {
	
            private int Id;
        
            private String CreatedTime;
        
            private String UpdateTime;
        
            private String Name;
        
            private String Password;
        
            private int SystemRoleId;
        
            private String Department;
        
            private String LastLoginIP;
        
            private String LastLoginTime;
        
            private String Email;
        
	
        public int getId() {
            return Id;
        }
        public void setId(int Id) {
            this.Id = Id;
        }
        
        public String getCreatedTime() {
            return CreatedTime;
        }
        public void setCreatedTime(String CreatedTime) {
            this.CreatedTime = CreatedTime;
        }
        
        public String getUpdateTime() {
            return UpdateTime;
        }
        public void setUpdateTime(String UpdateTime) {
            this.UpdateTime = UpdateTime;
        }
        
        public String getName() {
            return Name;
        }
        public void setName(String Name) {
            this.Name = Name;
        }
        
        public String getPassword() {
            return Password;
        }
        public void setPassword(String Password) {
            this.Password = Password;
        }
        
        public int getSystemRoleId() {
            return SystemRoleId;
        }
        public void setSystemRoleId(int SystemRoleId) {
            this.SystemRoleId = SystemRoleId;
        }
        
        public String getDepartment() {
            return Department;
        }
        public void setDepartment(String Department) {
            this.Department = Department;
        }
        
        public String getLastLoginIP() {
            return LastLoginIP;
        }
        public void setLastLoginIP(String LastLoginIP) {
            this.LastLoginIP = LastLoginIP;
        }
        
        public String getLastLoginTime() {
            return LastLoginTime;
        }
        public void setLastLoginTime(String LastLoginTime) {
            this.LastLoginTime = LastLoginTime;
        }
        
        public String getEmail() {
            return Email;
        }
        public void setEmail(String Email) {
            this.Email = Email;
        }
        
	
}
