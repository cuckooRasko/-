package com.ch.DHMSPro.service.admin;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;

import org.springframework.ui.Model;

import com.ch.DHMSPro.entity.MedicalProcess;

public interface MedicalProcessService {
	public String selectAllByPage(Model model, Integer currentPage, String act, HttpServletRequest  request);
	public String save_add(MedicalProcess medicalprocess, HttpServletRequest  request) throws IllegalStateException, IOException ;
	public String save_edit(MedicalProcess medicalprocess, HttpServletRequest  request) throws IllegalStateException, IOException ;
	public String add(MedicalProcess medicalprocess, Model model);
	public String edit(Model model,Integer id);
	public String detail(Model model, Integer id);
	
	public String delete(Integer id);
	public String importexcel(MedicalProcess medicalprocess, HttpServletRequest  request) throws IllegalStateException, IOException ;
	
}
