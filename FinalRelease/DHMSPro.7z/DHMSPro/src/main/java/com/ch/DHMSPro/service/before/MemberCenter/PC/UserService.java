package com.ch.DHMSPro.service.before.MemberCenter.PC;

import javax.servlet.http.HttpSession;

import org.springframework.ui.Model;

import com.ch.DHMSPro.entity.Member;

public interface UserService {
	public String login(Member member, HttpSession session, Model model);
	public String logout(Member member, HttpSession session, Model model);
}
