package com.ch.DHMSPro.controller.before.ForegroundDisplayInfo.PC;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.ch.DHMSPro.entity.Department;
import com.ch.DHMSPro.service.before.ForegroundDisplayInfo.PC.DepartmentService;
@Controller("ForegroundDisplayInfoPCDepartmentController")
@RequestMapping("/ForegroundDisplayInfoPC/Department")
public class DepartmentController {
	@Autowired
	private DepartmentService departmentService;
	
        @RequestMapping("/edit")
        public String edit(Model model, Integer id) {

            return departmentService.edit(model, id);
        }
        
        @RequestMapping("/save_edit")
        @ResponseBody
        public String save_edit(@ModelAttribute("department") Department department, HttpServletRequest  request) throws IllegalStateException, IOException {
            return departmentService.save_edit(department, request);
        }
        
        @RequestMapping("/index")
        public String selectAllByPage(Model model, Integer currentPage, String act,HttpServletRequest  request) {
            return departmentService.selectAllByPage(model, currentPage, act,request);
        }
        
        @RequestMapping("/detail")
        public String detail(Model model, Integer id) {
            return departmentService.detail(model, id);
        }
        
	
}
