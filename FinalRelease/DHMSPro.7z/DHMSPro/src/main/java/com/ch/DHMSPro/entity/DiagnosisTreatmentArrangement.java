package com.ch.DHMSPro.entity;

import org.springframework.web.multipart.MultipartFile;

public class DiagnosisTreatmentArrangement {
	
            private int Id;
        
            private String CreatedTime;
        
            private String UpdateTime;
        
            private int DepartmentId;
        
            private String Name;
        
            private String StartingTime;
        
            private String EndTime;
        
            private int DoctorId;
        
            private int NumberOfDiagnoses;
        
            private int UsageAmount;
        
            private int RemainingAmount;
        
            private String ScheduleStatus;
        
            private String AppointmentStartTime;
        
            private String AppointmentEndTime;
        
	
        public int getId() {
            return Id;
        }
        public void setId(int Id) {
            this.Id = Id;
        }
        
        public String getCreatedTime() {
            return CreatedTime;
        }
        public void setCreatedTime(String CreatedTime) {
            this.CreatedTime = CreatedTime;
        }
        
        public String getUpdateTime() {
            return UpdateTime;
        }
        public void setUpdateTime(String UpdateTime) {
            this.UpdateTime = UpdateTime;
        }
        
        public int getDepartmentId() {
            return DepartmentId;
        }
        public void setDepartmentId(int DepartmentId) {
            this.DepartmentId = DepartmentId;
        }
        
        public String getName() {
            return Name;
        }
        public void setName(String Name) {
            this.Name = Name;
        }
        
        public String getStartingTime() {
            return StartingTime;
        }
        public void setStartingTime(String StartingTime) {
            this.StartingTime = StartingTime;
        }
        
        public String getEndTime() {
            return EndTime;
        }
        public void setEndTime(String EndTime) {
            this.EndTime = EndTime;
        }
        
        public int getDoctorId() {
            return DoctorId;
        }
        public void setDoctorId(int DoctorId) {
            this.DoctorId = DoctorId;
        }
        
        public int getNumberOfDiagnoses() {
            return NumberOfDiagnoses;
        }
        public void setNumberOfDiagnoses(int NumberOfDiagnoses) {
            this.NumberOfDiagnoses = NumberOfDiagnoses;
        }
        
        public int getUsageAmount() {
            return UsageAmount;
        }
        public void setUsageAmount(int UsageAmount) {
            this.UsageAmount = UsageAmount;
        }
        
        public int getRemainingAmount() {
            return RemainingAmount;
        }
        public void setRemainingAmount(int RemainingAmount) {
            this.RemainingAmount = RemainingAmount;
        }
        
        public String getScheduleStatus() {
            return ScheduleStatus;
        }
        public void setScheduleStatus(String ScheduleStatus) {
            this.ScheduleStatus = ScheduleStatus;
        }
        
        public String getAppointmentStartTime() {
            return AppointmentStartTime;
        }
        public void setAppointmentStartTime(String AppointmentStartTime) {
            this.AppointmentStartTime = AppointmentStartTime;
        }
        
        public String getAppointmentEndTime() {
            return AppointmentEndTime;
        }
        public void setAppointmentEndTime(String AppointmentEndTime) {
            this.AppointmentEndTime = AppointmentEndTime;
        }
        
	
}
