package com.ch.DHMSPro.repository.admin;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.ch.DHMSPro.entity.MedicalProcess;

@Mapper
public interface MedicalProcessRepository {
	int add(MedicalProcess medicalprocess);
	int update(MedicalProcess medicalprocess);
	int selectAll(
        @Param("Name") String  Name
        );
	MedicalProcess select(Integer id);
	List<Map> selectAllByPage(@Param("startIndex") int startIndex, @Param("perPageSize") int perPageSize,
        @Param("Name") String  Name
        );
	int  delete(Integer id);
	List<MedicalProcess> selectAllRecords();
	
	
        MedicalProcess selectByName(String Name);

        
	
        List<MedicalProcess> selectAllName();

        
	
}
