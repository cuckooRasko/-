package com.ch.DHMSPro.controller.before.FrontEnd.PC;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.ch.DHMSPro.entity.Member;
import com.ch.DHMSPro.service.before.FrontEnd.PC.MemberService;
@Controller("FrontEndPCMemberController")
@RequestMapping("/FrontEndPC/Member")
public class MemberController {
	@Autowired
	private MemberService memberService;
	
        @RequestMapping("/add")
        public String add(@ModelAttribute("member") Member member, Model model) {

            return memberService.add(member, model);
        }
        
        @RequestMapping("/save_add")
        @ResponseBody
        public String save_add(@ModelAttribute("member") Member member, HttpServletRequest  request) throws IllegalStateException, IOException {
            return memberService.save_add(member,request);
        }
        
	
}
