package com.ch.DHMSPro.repository.admin;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.ch.DHMSPro.entity.DiagnosisTreatmentRegistered;

@Mapper
public interface DiagnosisTreatmentRegisteredRepository {
	int add(DiagnosisTreatmentRegistered diagnosistreatmentregistered);
	int update(DiagnosisTreatmentRegistered diagnosistreatmentregistered);
	int selectAll(
        @Param("DiagnosisTreatmentArrangementId") String  DiagnosisTreatmentArrangementId
        ,
        @Param("Name") String  Name
        ,
        @Param("RegistrationTime") String  RegistrationTime
        ,
        @Param("State") String  State
        );
	DiagnosisTreatmentRegistered select(Integer id);
	List<Map> selectAllByPage(@Param("startIndex") int startIndex, @Param("perPageSize") int perPageSize,
        @Param("DiagnosisTreatmentArrangementId") String  DiagnosisTreatmentArrangementId
        ,
        @Param("Name") String  Name
        ,
        @Param("RegistrationTime") String  RegistrationTime
        ,
        @Param("State") String  State
        );
	int  delete(Integer id);
	List<DiagnosisTreatmentRegistered> selectAllRecords();
	
	
        DiagnosisTreatmentRegistered selectByName(String Name);

        
	
        List<DiagnosisTreatmentRegistered> selectAllName();

        
	
}
