package com.ch.DHMSPro.repository.before.DoctorCenter.PC;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.ch.DHMSPro.entity.DiagnosisTreatmentMedicalRecord;

@Mapper
public interface DoctorCenterPCDiagnosisTreatmentMedicalRecordRepository {
	    
        int add(DiagnosisTreatmentMedicalRecord diagnosistreatmentmedicalrecord);
        
        int  delete(Integer id);
        
        DiagnosisTreatmentMedicalRecord select(Integer id);
        
        int update(DiagnosisTreatmentMedicalRecord diagnosistreatmentmedicalrecord);
        
        List<Map> selectAllByPage(@Param("startIndex") int startIndex, @Param("perPageSize") int perPageSize,
        @Param("DiagnosisTreatmentRegisteredId") String  DiagnosisTreatmentRegisteredId
        );
        
        
        
        int selectAll(
        @Param("DiagnosisTreatmentRegisteredId") String  DiagnosisTreatmentRegisteredId
        );
        
        List<DiagnosisTreatmentMedicalRecord> selectAllRecords();
        
	
}
