package com.ch.DHMSPro.repository.before.MemberCenter.PC;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.ch.DHMSPro.entity.Member;
@Mapper
public interface MemberCenterPCUserRepository {
	public List<Member> login(Member member);
}
