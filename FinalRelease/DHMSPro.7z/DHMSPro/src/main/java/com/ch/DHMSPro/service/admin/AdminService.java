package com.ch.DHMSPro.service.admin;

import javax.servlet.http.HttpSession;

import org.springframework.ui.Model;

import com.ch.DHMSPro.entity.SystemAccount;

public interface AdminService {
	public String login(SystemAccount systemAccount, HttpSession session, Model model);
	public String logout(SystemAccount systemAccount, HttpSession session, Model model);
}
