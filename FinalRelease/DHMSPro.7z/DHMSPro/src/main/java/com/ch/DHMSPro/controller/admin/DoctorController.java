package com.ch.DHMSPro.controller.admin;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.ch.DHMSPro.entity.Doctor;
import com.ch.DHMSPro.service.admin.DoctorService;

@Controller("DoctorController")
@RequestMapping("/admin/Doctor")
public class DoctorController extends AdminBaseController{
	@Autowired
	private DoctorService doctorService;
	@RequestMapping("/index")
	public String selectAllByPage(Model model, Integer currentPage, String act, HttpServletRequest  request) {
		return doctorService.selectAllByPage(model, currentPage, act,request);
	}
	@RequestMapping("/add")
	public String add(@ModelAttribute("doctor") Doctor doctor, Model model) {

		return doctorService.add(doctor, model);
	}
	@RequestMapping("/save_add")
	@ResponseBody
	public String save_add(@ModelAttribute("doctor") Doctor doctor, HttpServletRequest  request) throws IllegalStateException, IOException {
		return doctorService.save_add(doctor,request);
	}
	@RequestMapping("/edit")
	public String edit(Model model, Integer id) {

		return doctorService.edit(model, id);
	}
	@RequestMapping("/save_edit")
	@ResponseBody
	public String save_edit(@ModelAttribute("doctor") Doctor doctor, HttpServletRequest  request) throws IllegalStateException, IOException {
		return doctorService.save_edit(doctor, request);
	}
	@RequestMapping("/detail")
	public String detail(Model model, Integer id) {
		return doctorService.detail(model, id);
	}
	@RequestMapping("/delete")
	public String delete(Integer id) {
		return doctorService.delete(id);
	}
	/**
	 * 导入excel
	 */
	@RequestMapping("/importexcel")
	@ResponseBody
	public String importexcel(@ModelAttribute("doctor") Doctor doctor, HttpServletRequest  request) throws IllegalStateException,IOException {
		return doctorService.importexcel(doctor,request);
		
	}
}
