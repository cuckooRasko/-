package com.ch.DHMSPro.repository.before.FrontEnd.PC;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.ch.DHMSPro.entity.Member;

@Mapper
public interface FrontEndPCMemberRepository {
	    
        int add(Member member);
        
	
}
