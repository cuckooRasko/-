package com.ch.DHMSPro.controller.admin;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.ch.DHMSPro.entity.DiagnosisTreatmentArrangement;
import com.ch.DHMSPro.service.admin.DiagnosisTreatmentArrangementService;

@Controller("DiagnosisTreatmentArrangementController")
@RequestMapping("/admin/DiagnosisTreatmentArrangement")
public class DiagnosisTreatmentArrangementController extends AdminBaseController{
	@Autowired
	private DiagnosisTreatmentArrangementService diagnosistreatmentarrangementService;
	@RequestMapping("/index")
	public String selectAllByPage(Model model, Integer currentPage, String act, HttpServletRequest  request) {
		return diagnosistreatmentarrangementService.selectAllByPage(model, currentPage, act,request);
	}
	@RequestMapping("/add")
	public String add(@ModelAttribute("diagnosistreatmentarrangement") DiagnosisTreatmentArrangement diagnosistreatmentarrangement, Model model) {

		return diagnosistreatmentarrangementService.add(diagnosistreatmentarrangement, model);
	}
	@RequestMapping("/save_add")
	@ResponseBody
	public String save_add(@ModelAttribute("diagnosistreatmentarrangement") DiagnosisTreatmentArrangement diagnosistreatmentarrangement, HttpServletRequest  request) throws IllegalStateException, IOException {
		return diagnosistreatmentarrangementService.save_add(diagnosistreatmentarrangement,request);
	}
	@RequestMapping("/edit")
	public String edit(Model model, Integer id) {

		return diagnosistreatmentarrangementService.edit(model, id);
	}
	@RequestMapping("/save_edit")
	@ResponseBody
	public String save_edit(@ModelAttribute("diagnosistreatmentarrangement") DiagnosisTreatmentArrangement diagnosistreatmentarrangement, HttpServletRequest  request) throws IllegalStateException, IOException {
		return diagnosistreatmentarrangementService.save_edit(diagnosistreatmentarrangement, request);
	}
	@RequestMapping("/detail")
	public String detail(Model model, Integer id) {
		return diagnosistreatmentarrangementService.detail(model, id);
	}
	@RequestMapping("/delete")
	public String delete(Integer id) {
		return diagnosistreatmentarrangementService.delete(id);
	}
	/**
	 * 导入excel
	 */
	@RequestMapping("/importexcel")
	@ResponseBody
	public String importexcel(@ModelAttribute("diagnosistreatmentarrangement") DiagnosisTreatmentArrangement diagnosistreatmentarrangement, HttpServletRequest  request) throws IllegalStateException,IOException {
		return diagnosistreatmentarrangementService.importexcel(diagnosistreatmentarrangement,request);
		
	}
}
