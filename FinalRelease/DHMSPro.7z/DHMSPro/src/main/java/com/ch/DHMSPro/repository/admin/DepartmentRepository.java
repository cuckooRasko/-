package com.ch.DHMSPro.repository.admin;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.ch.DHMSPro.entity.Department;

@Mapper
public interface DepartmentRepository {
	int add(Department department);
	int update(Department department);
	int selectAll(
        @Param("Name") String  Name
        );
	Department select(Integer id);
	List<Map> selectAllByPage(@Param("startIndex") int startIndex, @Param("perPageSize") int perPageSize,
        @Param("Name") String  Name
        );
	int  delete(Integer id);
	List<Department> selectAllRecords();
	
	
        Department selectByName(String Name);

        
	
        List<Department> selectAllName();

        
	
}
