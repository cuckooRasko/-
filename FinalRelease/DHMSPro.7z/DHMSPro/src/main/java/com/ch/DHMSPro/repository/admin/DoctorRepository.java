package com.ch.DHMSPro.repository.admin;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.ch.DHMSPro.entity.Doctor;

@Mapper
public interface DoctorRepository {
	int add(Doctor doctor);
	int update(Doctor doctor);
	int selectAll(
        @Param("Name") String  Name
        );
	Doctor select(Integer id);
	List<Map> selectAllByPage(@Param("startIndex") int startIndex, @Param("perPageSize") int perPageSize,
        @Param("Name") String  Name
        );
	int  delete(Integer id);
	List<Doctor> selectAllRecords();
	
	
        Doctor selectByName(String Name);

        
	
        List<Doctor> selectAllName();

        
	
}
