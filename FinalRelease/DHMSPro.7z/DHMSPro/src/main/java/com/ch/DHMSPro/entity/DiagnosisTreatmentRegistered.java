package com.ch.DHMSPro.entity;

import org.springframework.web.multipart.MultipartFile;

public class DiagnosisTreatmentRegistered {
	
            private int Id;
        
            private String CreatedTime;
        
            private String UpdateTime;
        
            private int DiagnosisTreatmentArrangementId;
        
            private int MemberId;
        
            private String Name;
        
            private String RegistrationTime;
        
            private String CancellationTime;
        
            private String State;
        
	
        public int getId() {
            return Id;
        }
        public void setId(int Id) {
            this.Id = Id;
        }
        
        public String getCreatedTime() {
            return CreatedTime;
        }
        public void setCreatedTime(String CreatedTime) {
            this.CreatedTime = CreatedTime;
        }
        
        public String getUpdateTime() {
            return UpdateTime;
        }
        public void setUpdateTime(String UpdateTime) {
            this.UpdateTime = UpdateTime;
        }
        
        public int getDiagnosisTreatmentArrangementId() {
            return DiagnosisTreatmentArrangementId;
        }
        public void setDiagnosisTreatmentArrangementId(int DiagnosisTreatmentArrangementId) {
            this.DiagnosisTreatmentArrangementId = DiagnosisTreatmentArrangementId;
        }
        
        public int getMemberId() {
            return MemberId;
        }
        public void setMemberId(int MemberId) {
            this.MemberId = MemberId;
        }
        
        public String getName() {
            return Name;
        }
        public void setName(String Name) {
            this.Name = Name;
        }
        
        public String getRegistrationTime() {
            return RegistrationTime;
        }
        public void setRegistrationTime(String RegistrationTime) {
            this.RegistrationTime = RegistrationTime;
        }
        
        public String getCancellationTime() {
            return CancellationTime;
        }
        public void setCancellationTime(String CancellationTime) {
            this.CancellationTime = CancellationTime;
        }
        
        public String getState() {
            return State;
        }
        public void setState(String State) {
            this.State = State;
        }
        
	
}
