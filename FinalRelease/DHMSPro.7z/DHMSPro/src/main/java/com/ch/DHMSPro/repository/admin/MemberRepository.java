package com.ch.DHMSPro.repository.admin;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.ch.DHMSPro.entity.Member;

@Mapper
public interface MemberRepository {
	int add(Member member);
	int update(Member member);
	int selectAll(
        @Param("Name") String  Name
        );
	Member select(Integer id);
	List<Map> selectAllByPage(@Param("startIndex") int startIndex, @Param("perPageSize") int perPageSize,
        @Param("Name") String  Name
        );
	int  delete(Integer id);
	List<Member> selectAllRecords();
	
	
        Member selectByName(String Name);

        
	
        List<Member> selectAllName();

        
	
}
