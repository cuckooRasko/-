package com.ch.DHMSPro.service.admin;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.tomcat.util.http.fileupload.servlet.ServletFileUpload;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.util.WebUtils;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.stream.Collectors;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ch.DHMSPro.entity.DiagnosisTreatmentArrangement;
import com.ch.DHMSPro.repository.admin.DiagnosisTreatmentArrangementRepository;
import com.ch.DHMSPro.util.MyUtil;
import com.ch.DHMSPro.util.ExcelUtil;
import com.ch.DHMSPro.util.utlitComm;

import com.ch.DHMSPro.repository.admin.DepartmentRepository;
        
import com.ch.DHMSPro.repository.admin.DoctorRepository;
        

import com.ch.DHMSPro.entity.Department;        

        
import com.ch.DHMSPro.entity.Doctor;        

        
@Service("DiagnosisTreatmentArrangementServiceImpl")
public class DiagnosisTreatmentArrangementServiceImpl implements DiagnosisTreatmentArrangementService{
	@Autowired
	private DiagnosisTreatmentArrangementRepository diagnosistreatmentarrangementRepository;
	
        @Autowired
        private DepartmentRepository departmentRepository;
        
        @Autowired
        private DoctorRepository doctorRepository;
        
	@Override
	public String selectAllByPage(Model model,Integer currentPage, String act,HttpServletRequest  request) {
		Map<String,String>  searchFieldAndContent = getAllRequestParam(request);
		
		//共多少个商品
	  	int totalCount = diagnosistreatmentarrangementRepository.selectAll(    
        searchFieldAndContent.get("DepartmentId")  
        ,    
        searchFieldAndContent.get("Name")  
        ,    
        searchFieldAndContent.get("StartingTime")  
        ,    
        searchFieldAndContent.get("EndTime")  
        );
	  	//计算共多少页
	  	int pageSize = 5;
		if (currentPage == null) {
	  		currentPage = 1;
	  	}
	  	int totalPage = (int)Math.ceil(totalCount*1.0/pageSize);
	  	List<Map> curPageObject = diagnosistreatmentarrangementRepository.selectAllByPage((currentPage-1)*pageSize, pageSize,    
        searchFieldAndContent.get("DepartmentId")  
        ,    
        searchFieldAndContent.get("Name")  
        ,    
        searchFieldAndContent.get("StartingTime")  
        ,    
        searchFieldAndContent.get("EndTime")  
        );
		
        //更新常量
        Map<String, Map<String, String>> publicDict = utlitComm.publicDict();
        
        
         Map<String, String> ScheduleStatusList = publicDict.get("ScheduleStatus").entrySet().stream().collect(Collectors.toMap(entry -> entry.getValue(), entry -> entry.getKey()));
        
        
        for (int i = 0 ; i<curPageObject.size();i++)    
        {
            
            
        curPageObject.get(i).put("ScheduleStatus",ScheduleStatusList.get(curPageObject.get(i).get("ScheduleStatus")));
        
            
        }
        
		
        List<Department> DepartmentList = departmentRepository.selectAllName();
        model.addAttribute("DepartmentList", DepartmentList);
        
        List<Doctor> DoctorList = doctorRepository.selectAllName();
        model.addAttribute("DoctorList", DoctorList);
        
		model.addAttribute("DiagnosisTreatmentArrangement", searchFieldAndContent);
 		model.addAttribute("curPageObject", curPageObject );
	    	model.addAttribute("totalPage", totalPage);
	    	model.addAttribute("currentPage", currentPage);
	    	model.addAttribute("act", act);
		return "admin/DiagnosisTreatmentArrangement/index";
	}

	@Override
	public String save_add(DiagnosisTreatmentArrangement diagnosistreatmentarrangement, HttpServletRequest  request) throws IllegalStateException, IOException {
			
		int n = diagnosistreatmentarrangementRepository.add(diagnosistreatmentarrangement);
		if(n > 0)//成功
			return "/admin/DiagnosisTreatmentArrangement/index?currentPage=1&act=select";
			//失败
		return "fail";//"admin/DiagnosisTreatmentArrangement/add";
		
	}
	@Override
	public String save_edit(DiagnosisTreatmentArrangement diagnosistreatmentarrangement, HttpServletRequest  request) throws IllegalStateException, IOException {
			
		int n = diagnosistreatmentarrangementRepository.update(diagnosistreatmentarrangement);
		if(n > 0)//成功
			return "/admin/DiagnosisTreatmentArrangement/index?currentPage=1&act=updateSelect";
			//失败
		return  "fail";//"admin/DiagnosisTreatmentArrangement/edit";	
	}
	@Override
	public String add(DiagnosisTreatmentArrangement diagnosistreatmentarrangement, Model model) {
		
        model.addAttribute("Department", departmentRepository.selectAllRecords());
        
        model.addAttribute("Doctor", doctorRepository.selectAllRecords());
        
		return "admin/DiagnosisTreatmentArrangement/add";
	}
	@Override
	public String edit(Model model,Integer id) {
		
        model.addAttribute("Department", departmentRepository.selectAllRecords());
        
        model.addAttribute("Doctor", doctorRepository.selectAllRecords());
        
		model.addAttribute("diagnosistreatmentarrangement", diagnosistreatmentarrangementRepository.select(id));
		return "admin/DiagnosisTreatmentArrangement/edit";
	}
	@Override
	public String detail(Model model, Integer id) {
		model.addAttribute("diagnosistreatmentarrangement", diagnosistreatmentarrangementRepository.select(id));
		return "admin/DiagnosisTreatmentArrangement/detail";		
	}

	@Override
	public String delete(Integer id) {
		
		diagnosistreatmentarrangementRepository.delete(id);
		return "redirect:/admin/DiagnosisTreatmentArrangement/index?currentPage=1&act=deleteSelect";
		
	}

	
        private String processFileUpload(MultipartFile myfile,HttpServletRequest  request) throws IllegalStateException, IOException {
    	String fileNewName = "";
    	System.out.println(myfile !=null);
    	
    	if(myfile !=null && !myfile.isEmpty()) {
			//上传文件路径（生产环境）
			String path = request.getServletContext().getRealPath("/images/");
			//获得上传文件原名
			//上传文件路径（开发环境）
			
			String fileName = myfile.getOriginalFilename();
			//对文件重命名
			fileNewName = MyUtil.getNewFileName(fileName);
			File filePath = new File(path + File.separator + fileNewName);
			//如果文件目录不存在，创建目录
			if(!filePath.getParentFile().exists()) {
				filePath.getParentFile().mkdirs();
			}
			//将上传文件保存到一个目标文件中
			myfile.transferTo(filePath);

		}
    	return fileNewName;
    }
    /*
    * 获取客户端请求参数中所有的信息
    * @param request
    * @return
    */
   private Map<String, String> getAllRequestParam(final HttpServletRequest request) {
       Map<String, String> res = new HashMap<String, String>();
       Enumeration<?> temp = request.getParameterNames();
       if (null != temp) {
           while (temp.hasMoreElements()) {
               String en = (String) temp.nextElement();
               String value = request.getParameter(en);
               res.put(en, value);
               //如果字段的值为空，判断若值为空，则删除这个字段>
               //if (null == res.get(en) || "".equals(res.get(en))) {
                   //res.remove(en);
               //}
           }
       }
       return res;
   }
   private String updateFileField(HttpServletRequest  request,String fileFieldName) throws IllegalStateException, IOException {		
		MultipartFile file = null;
		String fileNewName = "";
		boolean isMultipart = ServletFileUpload.isMultipartContent(request);
		if (isMultipart){
		    MultipartHttpServletRequest multipartRequest =
		    WebUtils.getNativeRequest(request,MultipartHttpServletRequest.class);
		    file = multipartRequest.getFile(fileFieldName);
		    if (!(file == null))
		    {
		    	fileNewName = processFileUpload(file,request);		    	
		    }   	
		}
		return fileNewName;
		
   }

              @Override
	public String importexcel(DiagnosisTreatmentArrangement diagnosistreatmentarrangement,HttpServletRequest  request) throws IllegalStateException, IOException {
		try {	
	   		
			MultipartFile file = null;
			String fileFieldName = "uploadExcelFile";
			boolean isMultipart = ServletFileUpload.isMultipartContent(request);
			if (isMultipart){
			    MultipartHttpServletRequest multipartRequest =
			    WebUtils.getNativeRequest(request,MultipartHttpServletRequest.class);
			    MultipartFile myfile = multipartRequest.getFile(fileFieldName);
			    String fileName = myfile.getOriginalFilename();
			    
			    List<Map<String,String>> readFileResult = ExcelUtil.readExcelFile(myfile); //excel读取到的数据
			    System.out.println(readFileResult);
			    DiagnosisTreatmentArrangement diagnosistreatmentarrangementTemp = new DiagnosisTreatmentArrangement();
			    
                            Department department = new Department();
        
                            Doctor doctor = new Doctor();
        
			    Map<String, Map<String, String>> publicDict = utlitComm.publicDict();
			    
        Map<String, String> ScheduleStatus = publicDict.get("ScheduleStatus");
        
			    Map<String,String> rowData =  new HashMap<String,String>();
			    for (int i=0;i<readFileResult.size();i++){
			    	rowData = readFileResult.get(i);
			    	for(String key : rowData.keySet()){
			    		   String value = rowData.get(key);
					   
                            if (key.equals("CreatedTime")) {
                               diagnosistreatmentarrangementTemp.setCreatedTime(value);
                            }
        
                           else  if (key.equals("UpdateTime")) {
                               diagnosistreatmentarrangementTemp.setUpdateTime(value);
                            }
        
                          else  if (key.equals("DepartmentId")) {
                                int DepartmentId = 0;
                                
                                department = departmentRepository.selectByName(value);
                                if (department != null) {
                                    DepartmentId = department.getId();
                                }
                                else
                                {
                                        //新增
                                        department = new Department();
                                        department.setName(value);
                                        DepartmentId = departmentRepository.add(department);
                                        DepartmentId = departmentRepository.selectByName(value).getId();
                                }
                               diagnosistreatmentarrangementTemp.setDepartmentId(DepartmentId);
                            }

        
                           else  if (key.equals("Name")) {
                               diagnosistreatmentarrangementTemp.setName(value);
                            }
        
                           else  if (key.equals("StartingTime")) {
                               diagnosistreatmentarrangementTemp.setStartingTime(value);
                            }
        
                           else  if (key.equals("EndTime")) {
                               diagnosistreatmentarrangementTemp.setEndTime(value);
                            }
        
                          else  if (key.equals("DoctorId")) {
                                int DoctorId = 0;
                                
                                doctor = doctorRepository.selectByName(value);
                                if (doctor != null) {
                                    DoctorId = doctor.getId();
                                }
                                else
                                {
                                        //新增
                                        doctor = new Doctor();
                                        doctor.setName(value);
                                        DoctorId = doctorRepository.add(doctor);
                                        DoctorId = doctorRepository.selectByName(value).getId();
                                }
                               diagnosistreatmentarrangementTemp.setDoctorId(DoctorId);
                            }

        
                           else  if (key.equals("NumberOfDiagnoses")) {
                               diagnosistreatmentarrangementTemp.setNumberOfDiagnoses(Integer.parseInt(value));
                            }
        
                           else  if (key.equals("UsageAmount")) {
                               diagnosistreatmentarrangementTemp.setUsageAmount(Integer.parseInt(value));
                            }
        
                           else  if (key.equals("RemainingAmount")) {
                               diagnosistreatmentarrangementTemp.setRemainingAmount(Integer.parseInt(value));
                            }
        
                           else  if (key.equals("ScheduleStatus")) {
                               diagnosistreatmentarrangementTemp.setScheduleStatus(ScheduleStatus.get(value));
                            }
        
                           else  if (key.equals("AppointmentStartTime")) {
                               diagnosistreatmentarrangementTemp.setAppointmentStartTime(value);
                            }
        
                           else  if (key.equals("AppointmentEndTime")) {
                               diagnosistreatmentarrangementTemp.setAppointmentEndTime(value);
                            }
         
			    	}
			    	diagnosistreatmentarrangementRepository.add(diagnosistreatmentarrangementTemp); //添加入库
			    	diagnosistreatmentarrangementTemp = new DiagnosisTreatmentArrangement();
			    	

			    }
			return "ok";
			}
			else {
				return "数据文件不存在";
			}
		}catch (Exception e) {
			e.printStackTrace();
			return "数据导入失败，请规范导入模板";
		}
		
	}

}
