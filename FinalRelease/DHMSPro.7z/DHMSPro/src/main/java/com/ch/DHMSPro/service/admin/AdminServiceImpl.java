package com.ch.DHMSPro.service.admin;

import java.util.List;
import java.util.HashMap;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;

import com.ch.DHMSPro.entity.SystemAccount;
import com.ch.DHMSPro.repository.admin.AdminRepository;



@Service
public class AdminServiceImpl implements AdminService{
	@Autowired
	private AdminRepository adminRepository;
	
	@Override
	public String login(SystemAccount systemAccount, HttpSession session, Model model) {
		List<SystemAccount> list = adminRepository.login(systemAccount);
		if(list.size() > 0) {//登录成功
			session.setAttribute("systemAccount", systemAccount);

			

			return "admin/Login/index";
		}else {//登录失败
			model.addAttribute("errorMessage", "用户名或密码错误！");
			return "admin/Login/login";
		}
	}
	@Override
	public String logout(SystemAccount systemAccount, HttpSession session, Model model) {
		session.setAttribute("systemAccount", null);
		return "admin/Login/login";
		
	}
	
}
