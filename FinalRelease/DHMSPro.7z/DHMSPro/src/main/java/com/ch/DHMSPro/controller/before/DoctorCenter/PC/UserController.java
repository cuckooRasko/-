package com.ch.DHMSPro.controller.before.DoctorCenter.PC;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.ch.DHMSPro.entity.Doctor;
import com.ch.DHMSPro.service.before.DoctorCenter.PC.UserService;
@Controller("DoctorCenterPCDoctorUserController")
@RequestMapping("/DoctorCenterPC")
public class UserController {
	@Autowired
	private UserService userService;
	@RequestMapping("/toLogin")
	public String toLogin(@ModelAttribute("Doctor") Doctor doctor) {
		//@ModelAttribute("doctor")与th:object="${doctor}"相对应
		return "before/DoctorCenter/login";
	}
	@RequestMapping("/login")
	public String login(@ModelAttribute("doctor") @Validated Doctor doctor,
			BindingResult rs, HttpSession session, Model model) {
		if(rs.hasErrors()){//验证失败
	        return "before/DoctorCenter/login";
	    }
		return userService.login(doctor, session, model);
	}
	@RequestMapping("/logout")
	public String logout(@ModelAttribute("doctor") Doctor doctor, HttpSession session, Model model) {
		return userService.logout(doctor, session, model);
	}	
}
