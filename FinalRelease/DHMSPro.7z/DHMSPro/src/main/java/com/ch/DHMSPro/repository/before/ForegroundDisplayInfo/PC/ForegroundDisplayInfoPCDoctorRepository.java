package com.ch.DHMSPro.repository.before.ForegroundDisplayInfo.PC;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.ch.DHMSPro.entity.Doctor;

@Mapper
public interface ForegroundDisplayInfoPCDoctorRepository {
	
        int update(Doctor doctor);
        
        Doctor select(Integer id);
        
        List<Map> selectAllByPage(@Param("startIndex") int startIndex, @Param("perPageSize") int perPageSize,
        @Param("Name") String  Name
        );
        
        Doctor selectByName(String Name);

        
        
        List<Doctor> selectAllName();

        
        
        int selectAll(
        @Param("Name") String  Name
        );
        
        List<Doctor> selectAllRecords();
        
	
}
