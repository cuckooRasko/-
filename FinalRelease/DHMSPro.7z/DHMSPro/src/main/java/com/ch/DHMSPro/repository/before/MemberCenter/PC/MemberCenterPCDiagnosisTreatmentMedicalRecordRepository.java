package com.ch.DHMSPro.repository.before.MemberCenter.PC;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.ch.DHMSPro.entity.DiagnosisTreatmentMedicalRecord;

@Mapper
public interface MemberCenterPCDiagnosisTreatmentMedicalRecordRepository {
	
        List<Map> selectAllByPage(@Param("startIndex") int startIndex, @Param("perPageSize") int perPageSize,
        @Param("DiagnosisTreatmentRegisteredId") String  DiagnosisTreatmentRegisteredId
        );
        
        
        
        int selectAll(
        @Param("DiagnosisTreatmentRegisteredId") String  DiagnosisTreatmentRegisteredId
        );
        
        List<DiagnosisTreatmentMedicalRecord> selectAllRecords();
        
        DiagnosisTreatmentMedicalRecord select(Integer id);
        
	
}
