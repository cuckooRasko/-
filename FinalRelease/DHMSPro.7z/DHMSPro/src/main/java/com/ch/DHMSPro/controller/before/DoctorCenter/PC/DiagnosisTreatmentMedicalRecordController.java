package com.ch.DHMSPro.controller.before.DoctorCenter.PC;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.ch.DHMSPro.entity.DiagnosisTreatmentMedicalRecord;
import com.ch.DHMSPro.service.before.DoctorCenter.PC.DiagnosisTreatmentMedicalRecordService;
@Controller("DoctorCenterPCDiagnosisTreatmentMedicalRecordController")
@RequestMapping("/DoctorCenterPC/DiagnosisTreatmentMedicalRecord")
public class DiagnosisTreatmentMedicalRecordController {
	@Autowired
	private DiagnosisTreatmentMedicalRecordService diagnosistreatmentmedicalrecordService;
	
        @RequestMapping("/add")
        public String add(@ModelAttribute("diagnosistreatmentmedicalrecord") DiagnosisTreatmentMedicalRecord diagnosistreatmentmedicalrecord, Model model) {

            return diagnosistreatmentmedicalrecordService.add(diagnosistreatmentmedicalrecord, model);
        }
        
        @RequestMapping("/save_add")
        @ResponseBody
        public String save_add(@ModelAttribute("diagnosistreatmentmedicalrecord") DiagnosisTreatmentMedicalRecord diagnosistreatmentmedicalrecord, HttpServletRequest  request) throws IllegalStateException, IOException {
            return diagnosistreatmentmedicalrecordService.save_add(diagnosistreatmentmedicalrecord,request);
        }
        
        @RequestMapping("/delete")
        public String delete(Integer id) {
            return diagnosistreatmentmedicalrecordService.delete(id);
        }
        
        @RequestMapping("/edit")
        public String edit(Model model, Integer id) {

            return diagnosistreatmentmedicalrecordService.edit(model, id);
        }
        
        @RequestMapping("/save_edit")
        @ResponseBody
        public String save_edit(@ModelAttribute("diagnosistreatmentmedicalrecord") DiagnosisTreatmentMedicalRecord diagnosistreatmentmedicalrecord, HttpServletRequest  request) throws IllegalStateException, IOException {
            return diagnosistreatmentmedicalrecordService.save_edit(diagnosistreatmentmedicalrecord, request);
        }
        
        @RequestMapping("/index")
        public String selectAllByPage(Model model, Integer currentPage, String act,HttpServletRequest  request) {
            return diagnosistreatmentmedicalrecordService.selectAllByPage(model, currentPage, act,request);
        }
        
        @RequestMapping("/detail")
        public String detail(Model model, Integer id) {
            return diagnosistreatmentmedicalrecordService.detail(model, id);
        }
        
	
}
