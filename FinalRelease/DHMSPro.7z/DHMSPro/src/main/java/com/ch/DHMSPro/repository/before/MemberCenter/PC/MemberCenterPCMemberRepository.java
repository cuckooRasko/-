package com.ch.DHMSPro.repository.before.MemberCenter.PC;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.ch.DHMSPro.entity.Member;

@Mapper
public interface MemberCenterPCMemberRepository {
	
        int update(Member member);
        
        Member select(Integer id);
        
	
}
