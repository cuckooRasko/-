package com.ch.DHMSPro.service.before.MemberCenter.PC;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;

import org.springframework.ui.Model;

import com.ch.DHMSPro.entity.Member;

public interface MemberService {
	
        public String edit(Model model,Integer id);
        
        public String save_edit(Member member, HttpServletRequest  request) throws IllegalStateException, IOException ;
        
}
