package com.ch.DHMSPro.repository.before.ForegroundDisplayInfo.PC;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.ch.DHMSPro.entity.DiagnosisTreatmentArrangement;

@Mapper
public interface ForegroundDisplayInfoPCDiagnosisTreatmentArrangementRepository {
	
        int update(DiagnosisTreatmentArrangement diagnosistreatmentarrangement);
        
        DiagnosisTreatmentArrangement select(Integer id);
        
        List<Map> selectAllByPage(@Param("startIndex") int startIndex, @Param("perPageSize") int perPageSize,
        @Param("DepartmentId") String  DepartmentId
        ,
        @Param("Name") String  Name
        ,
        @Param("StartingTime") String  StartingTime
        ,
        @Param("EndTime") String  EndTime
        );
        
        DiagnosisTreatmentArrangement selectByName(String Name);

        
        
        List<DiagnosisTreatmentArrangement> selectAllName();

        
        
        int selectAll(
        @Param("DepartmentId") String  DepartmentId
        ,
        @Param("Name") String  Name
        ,
        @Param("StartingTime") String  StartingTime
        ,
        @Param("EndTime") String  EndTime
        );
        
        List<DiagnosisTreatmentArrangement> selectAllRecords();
        
	
}
